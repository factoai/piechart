"""Database operations — pgvector storage and retrieval."""

import json
import logging
import os

import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.extensions import register_adapter, AsIs

logger = logging.getLogger(__name__)


def adapt_list(lst):
    return AsIs(f"'{lst}'::vector")

register_adapter(list, adapt_list)


def get_connection():
    """Open a new database connection using env vars injected by ECS from Secrets Manager."""
    return psycopg2.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ["DB_PORT"]),
        dbname=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        connect_timeout=10,
        sslmode="require",
    )


def save_session(summary: str, embedding: list[float], agent_id: str | None, metadata: dict) -> str:
    """Insert a session summary and return the new row ID."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO goose_sessions (summary, embedding, agent_id, metadata)
                VALUES (%s, %s::vector, %s, %s)
                RETURNING id
                """,
                (summary, embedding, agent_id, json.dumps(metadata)),
            )
            return str(cur.fetchone()[0])


def search_sessions(query_embedding: list[float], limit: int, agent_id: str | None) -> list[dict]:
    """Return the top-K sessions most similar to the query embedding."""
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            if agent_id:
                cur.execute(
                    """
                    SELECT id, summary, agent_id, metadata, created_at,
                           1 - (embedding <=> %s::vector) AS similarity
                    FROM goose_sessions
                    WHERE agent_id = %s
                    ORDER BY embedding <=> %s::vector
                    LIMIT %s
                    """,
                    (query_embedding, agent_id, query_embedding, limit),
                )
            else:
                cur.execute(
                    """
                    SELECT id, summary, agent_id, metadata, created_at,
                           1 - (embedding <=> %s::vector) AS similarity
                    FROM goose_sessions
                    ORDER BY embedding <=> %s::vector
                    LIMIT %s
                    """,
                    (query_embedding, query_embedding, limit),
                )
            rows = cur.fetchall()
            return [
                {
                    "id": str(r["id"]),
                    "summary": r["summary"],
                    "agent_id": r["agent_id"],
                    "metadata": r["metadata"],
                    "created_at": r["created_at"].isoformat(),
                    "similarity": float(r["similarity"]),
                }
                for r in rows
            ]


def run_migrations():
    """Apply SQL migrations from the migrations directory."""
    import pathlib
    migrations_dir = pathlib.Path(__file__).parent.parent / "migrations"
    with get_connection() as conn:
        with conn.cursor() as cur:
            for sql_file in sorted(migrations_dir.glob("*.sql")):
                logger.info("Applying migration: %s", sql_file.name)
                cur.execute(sql_file.read_text())
        conn.commit()
    logger.info("Migrations complete.")
