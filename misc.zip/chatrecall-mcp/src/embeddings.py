"""Bedrock Titan Embed Text v2 — produces 1024-dimensional vectors."""

import json
import boto3
from functools import lru_cache

MODEL_ID = "amazon.titan-embed-text-v2:0"
DIMENSIONS = 1024


@lru_cache(maxsize=1)
def _client(region: str):
    return boto3.client("bedrock-runtime", region_name=region)


def embed(text: str, region: str) -> list[float]:
    """Return a 1024-dimensional embedding vector for the given text."""
    client = _client(region)
    body = json.dumps({
        "inputText": text[:8000],   # Titan v2 max input is ~8k tokens
        "dimensions": DIMENSIONS,
        "normalize": True,
    })
    response = client.invoke_model(
        modelId=MODEL_ID,
        body=body,
        contentType="application/json",
        accept="application/json",
    )
    return json.loads(response["body"].read())["embedding"]
