"""
chatrecall-mcp — shared session memory MCP server for Goose agent farms.

Tools exposed:
  save_session    — embed a session summary and store it in Aurora pgvector
  search_sessions — semantic search across all stored session summaries

Transport: streamable_http on port 8000
  /health  — HTTP GET health check (used by ECS)
  /mcp     — MCP streamable HTTP endpoint
"""

import logging
import os

import uvicorn
from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

import db
import embeddings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger(__name__)

AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

mcp = FastMCP(
    name="chatrecall-mcp",
    instructions=(
        "Provides persistent session memory for Goose agents. "
        "Use save_session after completing a task and search_sessions before starting "
        "a new task to recall relevant prior context."
    ),
)


@mcp.tool()
def save_session(
    summary: str,
    agent_id: str = "",
    metadata: dict = {},
) -> str:
    """
    Save a session summary to shared memory.

    Args:
        summary:  Concise description of what was accomplished in the session
                  (tasks completed, decisions made, files changed, errors resolved).
        agent_id: Optional identifier for the agent saving the session.
        metadata: Optional key-value pairs (e.g. project, branch, service names).

    Returns:
        The UUID of the stored session record.
    """
    embedding = embeddings.embed(summary, AWS_REGION)
    session_id = db.save_session(
        summary=summary,
        embedding=embedding,
        agent_id=agent_id or None,
        metadata=metadata,
    )
    logger.info("Saved session %s (agent=%s)", session_id, agent_id or "unset")
    return session_id


@mcp.tool()
def search_sessions(
    query: str,
    limit: int = 5,
    agent_id: str = "",
) -> list[dict]:
    """
    Search past session summaries by semantic similarity.

    Args:
        query:    Natural-language description of what you are looking for.
        limit:    Maximum number of sessions to return (default 5, max 20).
        agent_id: If set, restrict results to sessions from this agent only.

    Returns:
        List of matching sessions ordered by similarity (highest first).
    """
    limit = min(limit, 20)
    query_embedding = embeddings.embed(query, AWS_REGION)
    results = db.search_sessions(
        query_embedding=query_embedding,
        limit=limit,
        agent_id=agent_id or None,
    )
    logger.info("search_sessions query=%r returned %d results", query[:60], len(results))
    return results


async def health_check(request: Request):
    """HTTP GET /health — used by ECS task health checks."""
    return JSONResponse({"status": "ok"})


def build_app():
    mcp_app = mcp.streamable_http_app()
    from starlette.applications import Starlette
    return Starlette(routes=[
        Route("/health", health_check, methods=["GET"]),
        Mount("/mcp", app=mcp_app),
    ])


if __name__ == "__main__":
    logger.info("Running database migrations...")
    db.run_migrations()

    port = int(os.environ.get("PORT", "8000"))
    logger.info("Starting chatrecall-mcp on port %d", port)

    app = build_app()
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
