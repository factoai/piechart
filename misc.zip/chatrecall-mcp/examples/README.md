# chatrecall-mcp — Architecture & Data Flow

## Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Goose Agent  (ECS Fargate task)                                        │
│                                                                         │
│   End of session:                     Start of session:                 │
│   "Summarise what we did"             "What do I know about payments?"  │
│          │                                        │                     │
│          ▼                                        ▼                     │
│   save_session(summary="...")      search_sessions(query="payments...")  │
└──────────┬────────────────────────────────────────┬────────────────────┘
           │  streamable_http                        │  streamable_http
           │  /mcp                                   │  /mcp
           ▼                                         ▼
┌──────────────────────────────────────────────────────────────────────┐
│  chatrecall-mcp  (ECS Service — always on)                           │
│  chatrecall-mcp.goose-dev.local:8000                                 │
│                                                                      │
│   1. Receive summary / query text                                    │
│   2. Call Bedrock to produce embedding  ─────────────────────────┐  │
│   3. Store / search in Aurora pgvector  ──────────────────────┐  │  │
└───────────────────────────────────────────────────────────────┼──┼──┘
                                                                │  │
                           ┌────────────────────────────────────┘  │
                           │                                        │
                           ▼                                        ▼
          ┌─────────────────────────────┐     ┌──────────────────────────────┐
          │  Aurora Serverless v2       │     │  AWS Bedrock                 │
          │  Postgres + pgvector        │     │  Titan Embed Text v2         │
          │                             │     │                              │
          │  goose_sessions             │     │  Input:  text (up to 8k tok) │
          │  ┌──────────────────────┐  │     │  Output: vector(1024)        │
          │  │ id       UUID        │  │     │          normalised           │
          │  │ summary  TEXT        │  │     └──────────────────────────────┘
          │  │ embedding vector(1024)│  │
          │  │ agent_id TEXT        │  │
          │  │ metadata JSONB       │  │
          │  │ created_at TIMESTAMPTZ│  │
          │  └──────────────────────┘  │
          │                             │
          │  Search: cosine distance    │
          │  embedding <=> query_vec    │
          │  IVFFlat index (lists=100)  │
          └─────────────────────────────┘
```

## Data Flow

### Save (end of session)

```
Goose calls save_session(summary)
  → chatrecall embeds summary
        via Bedrock Titan Embed Text v2
  → stores (summary, vector, agent_id, metadata)
        in Aurora pgvector
  ← returns UUID
```

### Search (start of session)

```
Goose calls search_sessions(query)
  → chatrecall embeds query
        via Bedrock Titan Embed Text v2
  → SELECT top-K rows
        ORDER BY embedding <=> query_vec  (cosine distance)
  ← returns ranked list with similarity scores (0–1)
```

## Design Notes

- **chatrecall-mcp is the only component that calls Bedrock.** Goose sends plain text in and gets plain text back — the embedding model is an implementation detail of the MCP server.
- **Shared memory across the farm.** Because chatrecall-mcp is a persistent ECS Service (not per-agent), every Goose agent reads and writes to the same store simultaneously.
- **agent_id is optional.** Agents can tag their sessions for filtered recall (`search_sessions(query, agent_id="agent-1")`), or leave it unset to search across all agents.
- **Cosine similarity** is used rather than Euclidean distance because Titan Embed Text v2 outputs normalised vectors, making cosine the natural and most accurate distance metric.
