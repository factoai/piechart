-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Goose agent session summaries with vector embeddings
-- Titan Embed Text v2 produces 1024-dimensional vectors
CREATE TABLE IF NOT EXISTS goose_sessions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    summary     TEXT        NOT NULL,
    embedding   vector(1024),
    agent_id    TEXT,                        -- optional: tag which agent saved this
    metadata    JSONB       DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- IVFFlat index for approximate nearest-neighbour search
-- lists = 100 is a good starting point; tune upward as the table grows
CREATE INDEX IF NOT EXISTS goose_sessions_embedding_idx
    ON goose_sessions
    USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 100);

-- Index for filtering/sorting by agent or time
CREATE INDEX IF NOT EXISTS goose_sessions_agent_idx    ON goose_sessions (agent_id);
CREATE INDEX IF NOT EXISTS goose_sessions_created_idx  ON goose_sessions (created_at DESC);
