# chatrecall-mcp — Claude Code Context

## What this is

A shared session memory MCP server for Goose agent farms. Agents call `save_session` at the end of a session and `search_sessions` at the start of a new one. All agents in the farm share one store.

## Project layout

```
chatrecall-mcp/
├── Dockerfile                    # python:3.12-slim, non-root user, EXPOSE 8000
├── requirements.txt              # mcp[cli], psycopg2-binary, boto3, uvicorn
├── migrations/
│   └── 001_init.sql              # CREATE TABLE goose_sessions + IVFFlat index
└── src/
    ├── main.py                   # FastMCP tools, /health + /mcp routes, startup
    ├── db.py                     # psycopg2, get_connection(), save_session(), search_sessions(), run_migrations()
    └── embeddings.py             # Bedrock Titan Embed Text v2, lru_cache'd boto3 client
```

## MCP tools

- `save_session(summary, agent_id?, metadata?)` → UUID
- `search_sessions(query, limit?=5, agent_id?)` → list of `{id, summary, agent_id, metadata, created_at, similarity}`

## Transport

`streamable_http` on port 8000. Endpoints:
- `GET /health` — ECS health check, returns `{"status": "ok"}`
- `POST /mcp` — MCP endpoint

## Key technical details

- **Embedding:** Bedrock Titan Embed Text v2 — 1024 dimensions, normalised, max ~8k tokens. Only chatrecall-mcp calls Bedrock; Goose sees plain text in/out.
- **Search:** cosine distance (`embedding <=> query_vec`), IVFFlat index `lists=100` — tune upward as table grows.
- **Migrations:** `db.run_migrations()` is called at startup in `main.py` before uvicorn starts. Each `.sql` file in `migrations/` runs in alphabetical order.
- **DB connection:** `db.py` reads `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` from `os.environ` — injected by ECS execution role from Secrets Manager. No boto3 SM calls at runtime.
- **SSL:** `sslmode="require"` always set in `get_connection()`.

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `DB_HOST` | yes | Aurora endpoint |
| `DB_PORT` | yes | typically 5432 |
| `DB_NAME` | yes | |
| `DB_USER` | yes | |
| `DB_PASSWORD` | yes | |
| `AWS_REGION` | no | default `us-east-1` |
| `PORT` | no | default `8000` |

## Building

```bash
# Local platform
docker build -t chatrecall-mcp .

# For ECS Fargate (required)
docker build --platform linux/amd64 -t chatrecall-mcp .
```

## Running locally

Needs Postgres with pgvector and AWS credentials for Bedrock:

```bash
docker run --rm -p 8000:8000 \
  -e DB_HOST=host.docker.internal -e DB_PORT=5432 \
  -e DB_NAME=chatrecall -e DB_USER=postgres -e DB_PASSWORD=postgres \
  -e AWS_REGION=us-east-1 \
  -v ~/.aws:/root/.aws:ro \
  chatrecall-mcp
```

In the full local stack this runs as a Docker Compose service inside `cofy/`.

## AWS deployment

Managed by the `cofy/terraform/modules/chatrecall-mcp` Terraform module. Accessible at `chatrecall-mcp.goose-dev.local:8000` via Route53 Service Discovery. Images pushed via `../push-images.sh chatrecall`.
