# chatrecall-mcp

A shared session memory MCP server for Goose agent farms. It lets Goose agents save summaries of completed sessions and search past sessions by semantic similarity, so knowledge persists across sessions and is shared across all agents in a farm.

## How It Works

```
Goose agent                  chatrecall-mcp                    AWS Bedrock
    │                              │                                │
    │── save_session(summary) ────►│                                │
    │                              │── embed(summary) ─────────────►│
    │                              │◄── 1024-dim vector ────────────│
    │                              │── INSERT INTO goose_sessions ──►│ (Aurora pgvector)
    │◄── session UUID ─────────────│
    │
    │── search_sessions(query) ───►│
    │                              │── embed(query) ────────────────►│
    │                              │◄── 1024-dim vector ─────────────│
    │                              │── SELECT ... ORDER BY           │
    │                              │   cosine distance ─────────────►│ (Aurora pgvector)
    │◄── ranked list of sessions ──│
```

1. **Saving**: Goose calls `save_session` with a plain-text summary. The server embeds it using Amazon Bedrock Titan Embed Text v2 (1024 dimensions) and stores the summary + vector in Postgres (pgvector).
2. **Searching**: Goose calls `search_sessions` with a natural-language query. The server embeds the query the same way and runs an approximate nearest-neighbour search using cosine distance (`<=>`) against all stored sessions, returning the top-K results ranked by similarity score.
3. **Shared memory**: Because chatrecall-mcp is a persistent service (not per-agent), every Goose agent in the farm reads and writes to the same store.

## MCP Tools

### `save_session`

Save a session summary to shared memory.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `summary` | string | yes | What was accomplished — tasks completed, decisions made, files changed, errors resolved |
| `agent_id` | string | no | Optional tag to identify which agent saved this session |
| `metadata` | object | no | Optional key-value pairs (e.g. `{"project": "payments", "branch": "main"}`) |

Returns the UUID of the stored record.

### `search_sessions`

Search past session summaries by semantic similarity.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `query` | string | yes | Natural-language description of what you are looking for |
| `limit` | integer | no | Max results to return (default 5, max 20) |
| `agent_id` | string | no | If set, restrict results to sessions from this agent only |

Returns a list of matching sessions ordered by similarity (highest first), each containing `id`, `summary`, `agent_id`, `metadata`, `created_at`, and `similarity` (0–1).

## Transport

`streamable_http` on port `8000`.

| Path | Purpose |
|---|---|
| `GET /health` | Health check endpoint (used by ECS) — returns `{"status": "ok"}` |
| `POST /mcp` | MCP streamable HTTP endpoint |

## Project Layout

```
chatrecall-mcp/
├── Dockerfile
├── requirements.txt
├── migrations/
│   └── 001_init.sql        # Creates goose_sessions table + pgvector indexes
└── src/
    ├── main.py              # FastMCP server, HTTP routing, tool definitions
    ├── db.py                # Postgres connection, INSERT and cosine-search queries
    └── embeddings.py        # Bedrock Titan Embed Text v2 client
```

## Database Schema

```sql
CREATE TABLE goose_sessions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    summary     TEXT        NOT NULL,
    embedding   vector(1024),           -- Titan Embed Text v2 output
    agent_id    TEXT,                   -- optional agent tag
    metadata    JSONB       DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
```

Indexes:
- `ivfflat (embedding vector_cosine_ops) WITH (lists=100)` — approximate nearest-neighbour search
- `(agent_id)` — filter by agent
- `(created_at DESC)` — sort by recency

Migrations run automatically at startup before the HTTP server comes up.

## Configuration

All configuration is via environment variables.

| Variable | Required | Description |
|---|---|---|
| `DB_HOST` | yes | Postgres hostname |
| `DB_PORT` | yes | Postgres port (typically `5432`) |
| `DB_NAME` | yes | Database name |
| `DB_USER` | yes | Database user |
| `DB_PASSWORD` | yes | Database password |
| `AWS_REGION` | no | AWS region for Bedrock (default: `us-east-1`) |
| `PORT` | no | HTTP listen port (default: `8000`) |

In AWS, `DB_*` variables are injected from Secrets Manager by the ECS execution role at task startup. The chatrecall-mcp task role has `bedrock:InvokeModel` permission for Titan Embed Text v2.

## Building

```bash
# Build for the local platform
docker build -t chatrecall-mcp .

# Build for Linux/amd64 (required for ECS Fargate)
docker build --platform linux/amd64 -t chatrecall-mcp .
```

## Running Locally

Requires a Postgres instance with the `pgvector` extension installed and AWS credentials available for Bedrock calls.

```bash
docker run --rm \
  -p 8000:8000 \
  -e DB_HOST=host.docker.internal \
  -e DB_PORT=5432 \
  -e DB_NAME=chatrecall \
  -e DB_USER=postgres \
  -e DB_PASSWORD=postgres \
  -e AWS_REGION=us-east-1 \
  -v ~/.aws:/root/.aws:ro \
  chatrecall-mcp
```

Health check:
```bash
curl http://localhost:8000/health
# {"status": "ok"}
```

In the full local stack, chatrecall-mcp runs as a Docker Compose service inside the `cofy/` stack and is accessible to Goose at `http://chatrecall-mcp:8000/mcp` on the `enterprisetools` network.

## Deploying to AWS

Images are built and pushed to ECR using `push-images.sh` at the repo root:

```bash
git clone # common utils repo
./push-images.sh chatrecall
```

The ECS Service and Service Discovery DNS (`chatrecall-mcp.goose-dev.local:8000`) are managed by the `chatrecall-mcp` Terraform module. See [`../cofy/terraform/README.md`](../cofy/terraform/README.md) for the full deployment guide.

## Dependencies

| Package | Purpose |
|---|---|
| `mcp[cli]` | FastMCP framework — MCP server and streamable_http transport |
| `psycopg2-binary` | Postgres driver with pgvector list adapter |
| `boto3` | AWS SDK — Bedrock Titan Embed Text v2 client |
| `uvicorn` | ASGI server |
