#!/usr/bin/env bash
# docker-compat.sh — Detects Docker or Podman and normalises the environment.
#
# Source this before running any container commands:
#   source "$(dirname "${BASH_SOURCE[0]}")/docker-compat.sh"
#
# Exports:
#   CONTAINER_ENGINE    — "docker" or "podman"
#   DOCKER_SOCKET       — API socket path used as DOCKER_HOST (may be a temp path on macOS Podman)
#   DOCKER_SOCKET_MOUNT — socket path to bind-mount into containers; always the stable
#                         /var/run/docker.sock on macOS (Podman's forwarding socket), same
#                         as DOCKER_SOCKET on Linux. Use this in docker-compose volume mounts.
#   COMPOSE_CMD         — "docker compose" or "podman compose"
#   DOCKER_HOST         — set only for Podman (points docker-ce-cli at the Podman socket)

# ── Helper: resolve Podman socket path ────────────────────────────────────────
# IMPORTANT: does NOT call any 'podman' CLI commands. On Apple Silicon libkrun,
# all podman CLI calls (podman info, podman machine inspect, podman version) use
# SSH to the VM and can hang indefinitely even when the machine is running.
# We rely on socket file presence instead.
_find_podman_socket() {
    # 1. Honour an explicit DOCKER_HOST already set by the user or podman machine
    if [[ -n "${DOCKER_HOST:-}" ]]; then
        echo "${DOCKER_HOST#unix://}"; return
    fi
    # 2. macOS — use DARWIN_USER_TEMP_DIR to find the actual Podman machine API socket.
    #    This avoids 'podman machine inspect' (SSH-based, hangs on libkrun) and also
    #    avoids /var/run/docker.sock (docker-forwarding layer, unreliable for compose).
    if [[ "$(uname)" == "Darwin" ]]; then
        local tmpdir
        tmpdir="$(getconf DARWIN_USER_TEMP_DIR 2>/dev/null)"
        local api_sock="${tmpdir}podman/podman-machine-default-api.sock"
        [[ -S "$api_sock" ]] && { echo "$api_sock"; return; }
        # Fallback: docker-compatible forwarding socket
        [[ -S "/var/run/docker.sock" ]] && { echo "/var/run/docker.sock"; return; }
    fi
    # 3. Linux rootless
    local uid_sock="/run/user/$(id -u)/podman/podman.sock"
    [[ -S "$uid_sock" ]] && { echo "$uid_sock"; return; }
    # 4. Linux rootful
    [[ -S "/run/podman/podman.sock" ]] && { echo "/run/podman/podman.sock"; return; }
    echo ""
}

# ── Helper: wait for Podman API socket to accept connections ──────────────────
# After 'podman machine start' the socket file appears before the API server is
# fully ready. This polls via curl (no podman CLI / no SSH) until the /info
# endpoint responds or the timeout is reached.
_wait_podman_api() {
    local sock="$1"
    local max_wait=30
    local elapsed=0
    echo "▶ docker-compat: waiting for Podman API to be ready..."
    while (( elapsed < max_wait )); do
        if curl -sf --max-time 2 --unix-socket "$sock" \
               "http://localhost/v1.44/info" &>/dev/null 2>&1; then
            return 0
        fi
        sleep 1
        (( elapsed++ )) || true
    done
    echo "✘  docker-compat: Podman API socket not responding after ${max_wait}s." >&2
    echo "   Try: podman machine stop && podman machine start" >&2
    return 1
}

# ── Guard: CONTAINER_ENGINE pre-set by caller ─────────────────────────────────
# Validate the binary and daemon are available, then derive any missing vars.
if [[ -n "${CONTAINER_ENGINE:-}" ]]; then
    if ! command -v "${CONTAINER_ENGINE}" &>/dev/null; then
        echo "✘  docker-compat: CONTAINER_ENGINE=${CONTAINER_ENGINE} but '${CONTAINER_ENGINE}' not found on PATH." >&2
        echo "   Install ${CONTAINER_ENGINE} or unset CONTAINER_ENGINE to auto-detect." >&2
        return 1 2>/dev/null || exit 1
    fi

    if [[ "${CONTAINER_ENGINE}" == "podman" ]]; then
        # Avoid 'podman info' — it uses SSH to the libkrun VM and hangs on Apple
        # Silicon even when the machine is running. Check the API socket instead.
        if [[ -z "${DOCKER_SOCKET:-}" ]]; then
            PODMAN_SOCK=$(_find_podman_socket)
            if [[ -z "$PODMAN_SOCK" ]]; then
                echo "✘  docker-compat: Podman machine socket not found." >&2
                echo "   Run: podman machine start" >&2
                return 1 2>/dev/null || exit 1
            fi
            export DOCKER_SOCKET="$PODMAN_SOCK"
            export DOCKER_HOST="unix://${DOCKER_SOCKET}"
            # On macOS the API socket is a temp path that cannot be bind-mounted into
            # containers. Use the stable forwarding socket for volume mounts instead.
            if [[ "$(uname)" == "Darwin" ]]; then
                export DOCKER_SOCKET_MOUNT="/var/run/docker.sock"
            else
                export DOCKER_SOCKET_MOUNT="${DOCKER_SOCKET}"
            fi
        fi
        # Wait for the API to be ready before running any compose commands.
        # The socket file appears before the API server is fully initialised.
        _wait_podman_api "${DOCKER_SOCKET}" || { return 1 2>/dev/null || exit 1; }
    else
        if ! "${CONTAINER_ENGINE}" info &>/dev/null 2>&1; then
            echo "✘  docker-compat: '${CONTAINER_ENGINE}' is installed but not running." >&2
            echo "   Start Docker Desktop and try again." >&2
            return 1 2>/dev/null || exit 1
        fi
        if [[ -z "${DOCKER_SOCKET:-}" ]]; then
            export DOCKER_SOCKET="/var/run/docker.sock"
        fi
        export DOCKER_SOCKET_MOUNT="${DOCKER_SOCKET}"
    fi

    if [[ -z "${COMPOSE_CMD:-}" ]]; then
        if [[ "${CONTAINER_ENGINE}" == "podman" ]]; then
            # For Podman: prefer 'podman compose' over 'docker compose' v2.
            # Docker Desktop's compose plugin hangs on all Podman API calls.
            # docker-compose v1 (via podman compose) works correctly.
            if podman compose version &>/dev/null 2>&1; then
                export COMPOSE_CMD="podman compose"
            elif command -v podman-compose &>/dev/null; then
                export COMPOSE_CMD="podman-compose"
                echo "▶ docker-compat: using podman-compose as compose provider"
            elif command -v docker &>/dev/null && \
                 DOCKER_HOST="unix://${DOCKER_SOCKET}" docker compose version &>/dev/null 2>&1; then
                export COMPOSE_CMD="docker compose"
                echo "▶ docker-compat: using docker compose (v2) as compose provider for Podman"
            else
                echo "✘  docker-compat: no compose provider found for Podman." >&2
                echo "   Install one of:" >&2
                echo "     pip3 install podman-compose" >&2
                echo "     brew install docker-compose" >&2
                return 1 2>/dev/null || exit 1
            fi
        else
            export COMPOSE_CMD="docker compose"
        fi
    fi

    # Get engine version.
    # For Podman: use client-only --version flag (no daemon connection, safe on libkrun).
    # 'podman version' and 'docker version' both contact the server and can hang.
    if [[ "${CONTAINER_ENGINE}" == "podman" ]]; then
        _ENGINE_VERSION=$(podman --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
    else
        _ENGINE_VERSION=$("${CONTAINER_ENGINE}" version --format '{{.Server.Version}}' 2>/dev/null \
                          || "${CONTAINER_ENGINE}" version --format '{{.Version}}' 2>/dev/null \
                          || echo "unknown")
    fi
    echo "▶ docker-compat: engine=${CONTAINER_ENGINE}  version=${_ENGINE_VERSION}  socket=${DOCKER_SOCKET}"
    return 0
fi

# ── Auto-detect ───────────────────────────────────────────────────────────────
if command -v docker &>/dev/null && docker info &>/dev/null 2>&1; then
    # ── Docker ────────────────────────────────────────────────────────────────
    export CONTAINER_ENGINE=docker
    export DOCKER_SOCKET="${DOCKER_SOCKET:-/var/run/docker.sock}"
    export DOCKER_SOCKET_MOUNT="${DOCKER_SOCKET}"
    export COMPOSE_CMD="docker compose"
    DOCKER_VERSION=$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo "unknown")
    echo "▶ docker-compat: engine=docker  version=${DOCKER_VERSION}  socket=${DOCKER_SOCKET}"

elif command -v podman &>/dev/null; then
    # ── Podman ────────────────────────────────────────────────────────────────
    # Avoid 'podman info' — check the API socket directly (no SSH needed).
    PODMAN_SOCK=$(_find_podman_socket)
    if [[ -z "$PODMAN_SOCK" ]]; then
        echo "✘  docker-compat: Podman found but machine is not running." >&2
        echo "   Run: podman machine start" >&2
        return 1 2>/dev/null || exit 1
    fi
    export CONTAINER_ENGINE=podman
    export DOCKER_SOCKET="$PODMAN_SOCK"
    export DOCKER_HOST="unix://${DOCKER_SOCKET}"
    # On macOS the API socket is a temp path that cannot be bind-mounted into
    # containers. Use the stable forwarding socket for volume mounts instead.
    if [[ "$(uname)" == "Darwin" ]]; then
        export DOCKER_SOCKET_MOUNT="/var/run/docker.sock"
    else
        export DOCKER_SOCKET_MOUNT="${DOCKER_SOCKET}"
    fi

    # Wait for the API to be ready before running any compose commands.
    _wait_podman_api "${DOCKER_SOCKET}" || { return 1 2>/dev/null || exit 1; }

    # For Podman: prefer 'podman compose' over 'docker compose' v2.
    # Docker Desktop's compose plugin hangs on all Podman API calls.
    # docker-compose v1 (via podman compose) works correctly.
    if podman compose version &>/dev/null 2>&1; then
        export COMPOSE_CMD="podman compose"
    elif command -v podman-compose &>/dev/null; then
        export COMPOSE_CMD="podman-compose"
        echo "▶ docker-compat: using podman-compose as compose provider"
    elif command -v docker &>/dev/null && \
         DOCKER_HOST="unix://${DOCKER_SOCKET}" docker compose version &>/dev/null 2>&1; then
        export COMPOSE_CMD="docker compose"
        echo "▶ docker-compat: using docker compose (v2) as compose provider for Podman"
    else
        echo "✘  docker-compat: no compose provider found for Podman." >&2
        echo "   Install one of:" >&2
        echo "     pip3 install podman-compose" >&2
        echo "     brew install docker-compose" >&2
        return 1 2>/dev/null || exit 1
    fi

    # Get version via client-only --version flag to avoid SSH/daemon hang
    PODMAN_VERSION=$(podman --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
    echo "▶ docker-compat: engine=podman  version=${PODMAN_VERSION}  socket=${DOCKER_SOCKET}"

    # ── macOS SSH agent warning ───────────────────────────────────────────────
    # Docker Desktop forwards the macOS SSH agent into its VM automatically.
    # Podman machine does not — SSH agent forwarding into Podman containers on
    # macOS requires manual setup (see README for instructions).
    if [[ "$(uname)" == "Darwin" ]]; then
        echo "⚠  docker-compat: Podman on macOS — SSH agent forwarding is not automatic." >&2
        echo "   Git SSH operations inside Goose may fail. See README: Podman on macOS." >&2
    fi

else
    # ── Nothing found — give a clear diagnostic ───────────────────────────────
    if command -v docker &>/dev/null; then
        echo "✘  docker-compat: Docker found but daemon is not running — start Docker Desktop." >&2
    else
        echo "✘  docker-compat: neither docker nor podman found on PATH." >&2
        echo "   Install Docker Desktop or Podman Desktop and try again." >&2
    fi
    return 1 2>/dev/null || exit 1
fi
