#!/usr/bin/env bash
# push-images.sh — Build and push chatrecall-mcp and goose-agent images to ECR.
#
# Usage:
#   ./push-images.sh            # build and push all images
#   ./push-images.sh chatrecall # build and push chatrecall-mcp only
#   ./push-images.sh goose      # build and push goose-agent only
#   ./push-images.sh squid      # build and push squid-proxy only
#
# Prerequisites:
#   - Docker running
#   - AWS CLI with default profile configured
#   - Terraform dev environment already applied

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
TF_DIR="$ROOT_DIR/cofy/terraform/environments/dev"
REGION="us-east-1"
TARGET="${1:-both}"

# ── Colour helpers ─────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
WHITE='\033[0;97m'
BOLD='\033[1m'
NC='\033[0m'

log()    { echo -e "${CYAN}▶${NC} ${WHITE}$*${NC}"; }
ok()     { echo -e "${GREEN}✔${NC} ${WHITE}$*${NC}"; }
err()    { echo -e "${RED}✘${NC} ${RED}$*${NC}" >&2; }
banner() { echo -e "\n${BOLD}${WHITE}$*${NC}"; }

# ── Preflight ──────────────────────────────────────────────────────────────────
banner "── Preflight ──────────────────────────────────────────────────────────"

if ! docker info &>/dev/null; then
    err "Docker daemon is not running. Start Docker Desktop and try again."
    exit 1
fi

if ! aws sts get-caller-identity --profile default &>/dev/null; then
    err "AWS credentials not configured or expired. Run: aws configure"
    exit 1
fi

ACCOUNT_ID=$(aws sts get-caller-identity --profile default --query Account --output text)
ECR_REGISTRY="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com"

ok "AWS account : $ACCOUNT_ID"
ok "ECR registry: $ECR_REGISTRY"

# ── Read ECR repo URLs from Terraform outputs ──────────────────────────────────
banner "── Reading ECR URLs from Terraform outputs ────────────────────────────"

CHATRECALL_ECR=$(cd "$TF_DIR" && "$ROOT_DIR/cofy/terraform/tf" output -raw chatrecall_mcp_ecr_url 2>/dev/null)
GOOSE_ECR=$(cd "$TF_DIR" && "$ROOT_DIR/cofy/terraform/tf" output -raw goose_agent_ecr_url 2>/dev/null)
SQUID_ECR=$(cd "$TF_DIR" && "$ROOT_DIR/cofy/terraform/tf" output -raw squid_proxy_ecr_url 2>/dev/null)

ok "chatrecall-mcp ECR : $CHATRECALL_ECR"
ok "goose-agent ECR    : $GOOSE_ECR"
ok "squid-proxy ECR    : $SQUID_ECR"

# ── Authenticate Docker to ECR ─────────────────────────────────────────────────
banner "── Authenticating to ECR ──────────────────────────────────────────────"

aws ecr get-login-password --region "$REGION" --profile default \
    | docker login --username AWS --password-stdin "$ECR_REGISTRY"

ok "Authenticated to ECR."

# ── Build and push chatrecall-mcp ──────────────────────────────────────────────
push_chatrecall() {
    banner "── Building chatrecall-mcp ────────────────────────────────────────────"
    docker build \
        --platform linux/amd64 \
        -t "${CHATRECALL_ECR}:latest" \
        "$ROOT_DIR/chatrecall-mcp"
    ok "chatrecall-mcp image built."

    banner "── Pushing chatrecall-mcp ─────────────────────────────────────────────"
    docker push "${CHATRECALL_ECR}:latest"
    ok "chatrecall-mcp pushed to ECR."
}

# ── Build and push squid-proxy ────────────────────────────────────────────────
push_squid() {
    banner "── Building squid-proxy ───────────────────────────────────────────────"
    docker build \
        --platform linux/amd64 \
        -t "${SQUID_ECR}:latest" \
        "$ROOT_DIR/squid-proxy"
    ok "squid-proxy image built."

    banner "── Pushing squid-proxy ────────────────────────────────────────────────"
    docker push "${SQUID_ECR}:latest"
    ok "squid-proxy pushed to ECR."
}

# ── Build and push goose-agent ─────────────────────────────────────────────────
push_goose() {
    banner "── Building goose-agent ───────────────────────────────────────────────"
    docker build \
        --platform linux/amd64 \
        -t "${GOOSE_ECR}:latest" \
        "$ROOT_DIR/cofy"
    ok "goose-agent image built."

    banner "── Pushing goose-agent ────────────────────────────────────────────────"
    docker push "${GOOSE_ECR}:latest"
    ok "goose-agent pushed to ECR."
}

# ── Dispatch ───────────────────────────────────────────────────────────────────
case "$TARGET" in
    chatrecall) push_chatrecall ;;
    goose)      push_goose ;;
    squid)      push_squid ;;
    both)       push_chatrecall; push_goose; push_squid ;;
    *)
        err "Unknown target '$TARGET'. Use: chatrecall | goose | squid | both"
        exit 1
        ;;
esac

echo ""
ok "Done. Images are live in ECR and ready for ECS."
echo ""
log "To start a Goose session on AWS:  ./cofy/aws-start-session.sh"
