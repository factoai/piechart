# shutdown.ps1 — Commits the Goose session container to cofy-goose:local.
#
# Run this after exiting a Goose session started with local-startup.ps1.
# The container (cofy-goose-session) is left behind by local-startup.ps1 so
# this script can snapshot it before removing it.
#
# Usage: .\shutdown.ps1

$ErrorActionPreference = 'Stop'

. "$PSScriptRoot\docker-compat.ps1"

$Container = 'cofy-goose-session'

function Ok     { param($msg) Write-Host "OK $msg" -ForegroundColor Green }
function Warn   { param($msg) Write-Host "!! $msg" -ForegroundColor Yellow }
function Err    { param($msg) Write-Host "XX $msg" -ForegroundColor Red }
function Log    { param($msg) Write-Host ">> $msg" -ForegroundColor Cyan }
function Banner { param($msg) Write-Host "`n$msg" -ForegroundColor White }

Banner "-- Shutdown -- commit Goose session --------------------------------"

# ── Verify the session container exists ───────────────────────────────────────
& $CONTAINER_ENGINE container inspect $Container 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Err "Container '$Container' not found."
    Err "Either local-startup.ps1 was not used, the container was already removed, or shutdown.ps1 already ran."
    exit 1
}

$state = (& $CONTAINER_ENGINE container inspect --format '{{.State.Status}}' $Container)
if ($state -eq 'running') {
    Warn "Container is still running. Stop the Goose session first (type 'exit' inside Goose)."
    exit 1
}

# ── Commit session → cofy-goose:local ─────────────────────────────────────────
Log "Committing $Container -> cofy-goose:local ..."
& $CONTAINER_ENGINE commit `
    --format docker `
    --message "goose session $(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')" `
    $Container `
    cofy-goose:local
Ok "cofy-goose:local updated."

# ── Remove the spent session container ────────────────────────────────────────
Log "Removing session container..."
& $CONTAINER_ENGINE rm $Container
Ok "Container removed."

Write-Host ""
Ok "Done. Your installed software is baked into cofy-goose:local."
Ok "Next local-startup.ps1 will checkpoint it before the next session."
