# local-startup.ps1 — Brings up the full local developer platform on Windows.
#
# Steps:
#   1. Start the enterprisetools shared infrastructure stack
#   2. Wait for SonarQube, then prompt for a token if one is not yet set
#   3. Start semgrep-mcp and launch the Goose CLI
#
# Usage:
#   .\local-startup.ps1                     # interactive session
#   .\local-startup.ps1 "install rg fd"    # one-shot instruction

param(
    [string]$Instruction = ""
)

$ErrorActionPreference = 'Stop'

$ScriptDir            = $PSScriptRoot
$RootDir              = Split-Path (Split-Path $ScriptDir -Parent) -Parent
$EnterprisetoolsDir   = Join-Path $RootDir 'enterprisetools'
$CofyDir              = Join-Path $RootDir 'cofy'
$CofyEnv              = Join-Path $CofyDir '.env'

# ── Colour helpers ─────────────────────────────────────────────────────────────
function Log    { param($msg) Write-Host ">> $msg" -ForegroundColor Cyan }
function Ok     { param($msg) Write-Host "OK $msg" -ForegroundColor Green }
function Warn   { param($msg) Write-Host "!! $msg" -ForegroundColor Yellow }
function Err    { param($msg) Write-Host "XX $msg" -ForegroundColor Red }
function Plain  { param($msg) Write-Host "   $msg" -ForegroundColor White }
function Banner { param($msg) Write-Host "`n$msg" -ForegroundColor White }

# ── Helper: read a value from .env ────────────────────────────────────────────
function Get-EnvValue {
    param([string]$Key, [string]$EnvFile)
    $line = Get-Content $EnvFile -ErrorAction SilentlyContinue |
            Where-Object { $_ -match "^${Key}=" } |
            Select-Object -First 1
    if ($line) { return ($line -split '=', 2)[1].Trim() }
    return ''
}

# ── Helper: set a value in .env ───────────────────────────────────────────────
function Set-EnvValue {
    param([string]$Key, [string]$Value, [string]$EnvFile)
    $content = Get-Content $EnvFile
    if ($content -match "^${Key}=") {
        $content = $content -replace "^${Key}=.*", "${Key}=${Value}"
    } else {
        $content += "${Key}=${Value}"
    }
    $content | Set-Content $EnvFile -Encoding UTF8
}

# ── Preflight ─────────────────────────────────────────────────────────────────
Banner "-- Preflight -------------------------------------------------------"

# Detect Docker vs Podman
. "$ScriptDir\docker-compat.ps1"

if (-not (Test-Path $CofyEnv)) {
    Err "cofy\.env not found at $CofyEnv"
    exit 1
}

Ok "$CONTAINER_ENGINE is running."

# ── SSH agent (Windows) ───────────────────────────────────────────────────────
# Docker Desktop for Windows forwards the OpenSSH agent into containers at
# /run/host-services/ssh-auth.sock — the same path as macOS.
# The OpenSSH Authentication Agent Windows service must be running.
$sshAgentSvc = Get-Service -Name ssh-agent -ErrorAction SilentlyContinue
if ($sshAgentSvc -and $sshAgentSvc.Status -eq 'Running') {
    $keyCount = (& ssh-add -l 2>$null | Where-Object { $_ -notmatch 'no identities' }).Count
    if ($keyCount -eq 0) {
        Warn "SSH agent is running but has no loaded keys — git SSH operations may fail."
        Warn "Run: ssh-add ~\.ssh\id_ed25519"
    } else {
        Ok "SSH agent ready ($keyCount key(s) loaded)."
    }
    # Ensure SSH_AUTH_SOCK is set to the Docker Desktop path for Windows
    $currentSock = Get-EnvValue 'SSH_AUTH_SOCK' $CofyEnv
    if (-not $currentSock) {
        Set-EnvValue 'SSH_AUTH_SOCK' '/run/host-services/ssh-auth.sock' $CofyEnv
        Ok "SSH_AUTH_SOCK set to /run/host-services/ssh-auth.sock in cofy\.env"
    }
} elseif ($CONTAINER_ENGINE -eq 'docker') {
    Warn "OpenSSH Authentication Agent service is not running — git SSH operations will fail."
    Warn "To enable (run PowerShell as Administrator):"
    Warn "  Set-Service -Name ssh-agent -StartupType Automatic; Start-Service ssh-agent"
}

# ── Validate ANTHROPIC_API_KEY ────────────────────────────────────────────────
$AnthropicApiKey = Get-EnvValue 'ANTHROPIC_API_KEY' $CofyEnv
if (-not $AnthropicApiKey -or $AnthropicApiKey -eq 'your_anthropic_api_key_here') {
    Err "ANTHROPIC_API_KEY is not set in cofy\.env"
    Err "Add your key from https://console.anthropic.com/ and re-run."
    exit 1
}

Log "Validating Anthropic API key..."
try {
    $resp = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/models' `
                -Headers @{ 'x-api-key' = $AnthropicApiKey; 'anthropic-version' = '2023-06-01' } `
                -UseBasicParsing -ErrorAction Stop
    $httpStatus = $resp.StatusCode
} catch {
    $httpStatus = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
}

switch ($httpStatus) {
    200   { Ok "Anthropic API key is valid." }
    401   { Err "Anthropic API key is invalid (401 Unauthorized)."; Err "Update ANTHROPIC_API_KEY in cofy\.env and re-run."; exit 1 }
    403   { Err "Anthropic API key lacks permission (403 Forbidden)."; Err "Check your key's permissions at https://console.anthropic.com/"; exit 1 }
    0     { Warn "Could not reach api.anthropic.com — no internet or API is down. Continuing anyway." }
    default { Warn "Unexpected response from Anthropic API (HTTP $httpStatus) — continuing anyway." }
}

# ── Step 1: Start enterprisetools ─────────────────────────────────────────────
Banner "-- Step 1 of 3 -- Start shared infrastructure ----------------------"

$runningCount = (& $CONTAINER_ENGINE compose -f "$EnterprisetoolsDir\docker-compose.yml" ps -q 2>$null |
                  Where-Object { $_ }).Count
if ($runningCount -gt 0) {
    Ok "enterprisetools stack is already running ($runningCount container(s) up) -- skipping start."
} else {
    Log "Starting enterprisetools stack (SonarQube, Loki, Promtail, Grafana, Grafana-MCP)..."
    & $CONTAINER_ENGINE compose -f "$EnterprisetoolsDir\docker-compose.yml" up -d
    Ok "enterprisetools services started."
}

# ── Step 2: Wait for SonarQube and configure token ────────────────────────────
Banner "-- Step 2 of 3 -- Wait for SonarQube and configure token -----------"

Log "Waiting for SonarQube to become operational (this takes ~2 minutes on first boot)..."

$maxWait = 180
$interval = 10
$elapsed  = 0

while ($true) {
    $sonarStatus = ''
    try {
        $r = Invoke-WebRequest -Uri 'http://localhost:9000/api/system/status' -UseBasicParsing -ErrorAction Stop
        $sonarStatus = ($r.Content | ConvertFrom-Json).status
    } catch { $sonarStatus = 'starting' }

    if ($sonarStatus -eq 'UP') {
        Ok "SonarQube is operational."
        break
    }

    if ($elapsed -ge $maxWait) {
        Err "SonarQube did not become healthy within ${maxWait}s."
        Err "Check logs: $CONTAINER_ENGINE compose -f enterprisetools\docker-compose.yml logs sonarqube"
        exit 1
    }

    Log "  Status: '$sonarStatus' -- checking again in ${interval}s (${elapsed}s / ${maxWait}s)"
    Start-Sleep -Seconds $interval
    $elapsed += $interval
}

$currentToken = Get-EnvValue 'SONARQUBE_TOKEN' $CofyEnv
if (-not $currentToken -or $currentToken -eq 'your_sonarqube_token_here') {
    Warn "SONARQUBE_TOKEN is not yet set in cofy\.env"
    Write-Host ""
    Plain "To generate a token:"
    Plain "  1. Open http://localhost:9000  (default login: admin / admin)"
    Plain "  2. My Account -> Security -> Generate Token"
    Plain "  3. Type: User Token  |  Name: goose-mcp  -> click Generate"
    Write-Host ""

    $inputToken = Read-Host "  Paste your SonarQube token and press Enter"

    if (-not $inputToken) {
        Err "No token entered. Set SONARQUBE_TOKEN in cofy\.env manually and re-run."
        exit 1
    }

    Set-EnvValue 'SONARQUBE_TOKEN' $inputToken $CofyEnv
    Ok "SONARQUBE_TOKEN saved to cofy\.env"
} else {
    Ok "SONARQUBE_TOKEN is already configured."
}

# ── Step 3: Start Goose ────────────────────────────────────────────────────────
Banner "-- Step 3 of 3 -- Start Goose --------------------------------------"

$semgrepRunning = & $CONTAINER_ENGINE compose -f "$CofyDir\docker-compose.yml" ps -q semgrep-mcp 2>$null
if ($semgrepRunning) {
    Ok "semgrep-mcp is already running -- skipping start."
} else {
    Log "Starting semgrep-mcp..."
    & $CONTAINER_ENGINE compose -f "$CofyDir\docker-compose.yml" up -d semgrep-mcp
    Ok "semgrep-mcp is running."
}

$gooseVersion = (& $CONTAINER_ENGINE run --rm cofy-goose:local --version 2>$null) -join ''
$gooseProvider = Get-EnvValue 'GOOSE_PROVIDER' $CofyEnv
$gooseModel    = Get-EnvValue 'GOOSE_MODEL'    $CofyEnv

# ── Checkpoint: snapshot the current image before the session ─────────────────
$checkpointTag = "checkpoint-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
$imageExists = & $CONTAINER_ENGINE image inspect cofy-goose:local 2>$null
if ($LASTEXITCODE -eq 0) {
    & $CONTAINER_ENGINE tag cofy-goose:local "cofy-goose:$checkpointTag"
    Ok "Image checkpoint saved: cofy-goose:$checkpointTag"
} else {
    Warn "cofy-goose:local image not found -- skipping checkpoint."
}

Write-Host ""
Ok "All services are up. Launching Goose CLI..."
Ok "  Version  : $(if ($gooseVersion) { $gooseVersion } else { 'unknown' })"
Ok "  Provider : $gooseProvider"
Ok "  Model    : $gooseModel"
Write-Host ""

# ── Launch mode ───────────────────────────────────────────────────────────────
if ($Instruction) {
    Ok "One-shot mode: `"$Instruction`""
    Write-Host ""
    & $CONTAINER_ENGINE compose -f "$CofyDir\docker-compose.yml" run `
        --name cofy-goose-session goose run --text $Instruction
    Log "Instruction complete. Committing container -> cofy-goose:local ..."
    & $CONTAINER_ENGINE commit `
        --message "one-shot: $Instruction ($(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'))" `
        cofy-goose-session cofy-goose:local
    & $CONTAINER_ENGINE rm cofy-goose-session
    Ok "cofy-goose:local updated."
} else {
    Plain "When done, run .\shutdown.ps1 to commit the session and update cofy-goose:local."
    Write-Host ""
    & $CONTAINER_ENGINE compose -f "$CofyDir\docker-compose.yml" run --name cofy-goose-session goose session
}
