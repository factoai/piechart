# docker-compat.ps1 — Detects Docker or Podman and normalises the environment.
#
# Dot-source this before running any container commands:
#   . "$PSScriptRoot\docker-compat.ps1"
#
# Sets in caller scope:
#   $CONTAINER_ENGINE  — "docker" or "podman"
#   $env:DOCKER_SOCKET — path to the container API socket
#   $env:DOCKER_HOST   — set only for Podman (points docker-ce-cli at Podman socket)

# ── Helper: resolve Podman socket path ────────────────────────────────────────
# Defined first so the guard below can call it.
function _Find-PodmanSocket {
    # 1. Honour an explicit DOCKER_HOST already set (e.g. by podman machine start)
    if ($env:DOCKER_HOST) {
        return $env:DOCKER_HOST -replace '^unix://', ''
    }
    # 2. Windows named pipe — Podman machine default
    if (Test-Path '\\.\pipe\podman-machine-default') {
        return '//./pipe/podman-machine-default'
    }
    # 3. Ask podman machine for the socket path
    $sock = & podman machine inspect --format '{{.ConnectionInfo.PodmanSocket.Path}}' 2>$null |
            Select-Object -First 1
    if ($sock -and (Test-Path $sock)) { return $sock }
    return $null
}

# ── Guard: CONTAINER_ENGINE pre-set by caller ─────────────────────────────────
# Validate the binary and daemon are available, then derive any missing vars.
if ($env:CONTAINER_ENGINE) {
    $CONTAINER_ENGINE = $env:CONTAINER_ENGINE
    if (-not (Get-Command $CONTAINER_ENGINE -ErrorAction SilentlyContinue)) {
        Write-Host "XX  CONTAINER_ENGINE=$CONTAINER_ENGINE but '$CONTAINER_ENGINE' not found on PATH." -ForegroundColor Red
        Write-Host "    Install $CONTAINER_ENGINE or unset CONTAINER_ENGINE to auto-detect." -ForegroundColor Red
        exit 1
    }
    & $CONTAINER_ENGINE info 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "XX  '$CONTAINER_ENGINE' is installed but not running." -ForegroundColor Red
        if ($CONTAINER_ENGINE -eq 'podman') { Write-Host "    Run: podman machine start" -ForegroundColor Red }
        else { Write-Host "    Start Docker Desktop and try again." -ForegroundColor Red }
        exit 1
    }
    if (-not $env:DOCKER_SOCKET) {
        if ($CONTAINER_ENGINE -eq 'podman') {
            $sock = _Find-PodmanSocket
            $env:DOCKER_SOCKET = if ($sock) { $sock } else { '//./pipe/podman-machine-default' }
            $env:DOCKER_HOST   = "unix://$($env:DOCKER_SOCKET)"
        } else {
            $env:DOCKER_SOCKET = '//./pipe/docker_engine'
        }
    }
    # Verify compose provider when using Podman.
    # Prefer docker compose (v2 plugin) — it has better Podman API compatibility
    # than docker-compose v1, which can EOF during healthcheck polling.
    if ($CONTAINER_ENGINE -eq 'podman') {
        if ((Get-Command docker -ErrorAction SilentlyContinue) -and
            (& docker compose version 2>$null; $LASTEXITCODE -eq 0)) {
            Write-Host ">> docker-compat: using docker compose (v2) as compose provider for Podman" -ForegroundColor Cyan
        } elseif (& podman compose version 2>$null; $LASTEXITCODE -eq 0) {
            # podman compose available (may delegate to docker-compose v1)
        } elseif (Get-Command podman-compose -ErrorAction SilentlyContinue) {
            Write-Host ">> docker-compat: using podman-compose as compose provider" -ForegroundColor Cyan
        } else {
            Write-Host "XX  No compose provider found for Podman." -ForegroundColor Red
            Write-Host "    Install one of:" -ForegroundColor Red
            Write-Host "      pip install podman-compose" -ForegroundColor Red
            Write-Host "      winget install Docker.DockerCompose" -ForegroundColor Red
            exit 1
        }
    }
    $engineVersion = (& $CONTAINER_ENGINE version --format '{{.Server.Version}}' 2>$null) -join ''
    if (-not $engineVersion) { $engineVersion = (& $CONTAINER_ENGINE version --format '{{.Version}}' 2>$null) -join '' }
    if (-not $engineVersion) { $engineVersion = 'unknown' }
    Write-Host ">> docker-compat: engine=$CONTAINER_ENGINE  version=$engineVersion  socket=$($env:DOCKER_SOCKET)" -ForegroundColor Cyan
    return
}

# ── Auto-detect ───────────────────────────────────────────────────────────────
$_dockerCmd  = Get-Command docker  -ErrorAction SilentlyContinue
$_podmanCmd  = Get-Command podman  -ErrorAction SilentlyContinue

if ($_dockerCmd -and (& docker info 2>$null; $LASTEXITCODE -eq 0)) {
    # ── Docker ────────────────────────────────────────────────────────────────
    $CONTAINER_ENGINE       = 'docker'
    $env:CONTAINER_ENGINE   = 'docker'
    $env:DOCKER_SOCKET      = if ($env:DOCKER_SOCKET) { $env:DOCKER_SOCKET }
                              else { '//./pipe/docker_engine' }
    $dockerVersion = (& docker version --format '{{.Server.Version}}' 2>$null) -join ''
    if (-not $dockerVersion) { $dockerVersion = 'unknown' }
    Write-Host ">> docker-compat: engine=docker  version=$dockerVersion  socket=$($env:DOCKER_SOCKET)" -ForegroundColor Cyan

} elseif ($_podmanCmd -and (& podman info 2>$null; $LASTEXITCODE -eq 0)) {
    # ── Podman ────────────────────────────────────────────────────────────────
    $CONTAINER_ENGINE     = 'podman'
    $env:CONTAINER_ENGINE = 'podman'
    $sock = _Find-PodmanSocket
    if (-not $sock) {
        Write-Host "!!  podman socket not found — run: podman machine start" -ForegroundColor Yellow
    }
    $env:DOCKER_SOCKET = if ($sock) { $sock } else { '//./pipe/podman-machine-default' }
    $env:DOCKER_HOST   = "unix://$($env:DOCKER_SOCKET)"
    # Verify a compose provider is available
    # Prefer docker compose (v2 plugin) — it has better Podman API compatibility
    # than docker-compose v1, which can EOF during healthcheck polling.
    if ((Get-Command docker -ErrorAction SilentlyContinue) -and
        (& docker compose version 2>$null; $LASTEXITCODE -eq 0)) {
        Write-Host ">> docker-compat: using docker compose (v2) as compose provider for Podman" -ForegroundColor Cyan
    } elseif (& podman compose version 2>$null; $LASTEXITCODE -eq 0) {
        # podman compose available (may delegate to docker-compose v1)
    } elseif (Get-Command podman-compose -ErrorAction SilentlyContinue) {
        Write-Host ">> docker-compat: using podman-compose as compose provider" -ForegroundColor Cyan
    } else {
        Write-Host "XX  No compose provider found for Podman." -ForegroundColor Red
        Write-Host "    Install one of:" -ForegroundColor Red
        Write-Host "      pip install podman-compose" -ForegroundColor Red
        Write-Host "      winget install Docker.DockerCompose" -ForegroundColor Red
        exit 1
    }
    $podmanVersion = (& podman version --format '{{.Server.Version}}' 2>$null) -join ''
    if (-not $podmanVersion) { $podmanVersion = (& podman version --format '{{.Version}}' 2>$null) -join '' }
    if (-not $podmanVersion) { $podmanVersion = 'unknown' }
    Write-Host ">> docker-compat: engine=podman  version=$podmanVersion  socket=$($env:DOCKER_SOCKET)" -ForegroundColor Cyan

    # ── SSH agent warning ─────────────────────────────────────────────────────
    # Docker Desktop forwards the Windows SSH agent into its VM automatically.
    # Podman does not — git SSH inside Goose may fail.
    Write-Host "!!  Podman on Windows — SSH agent forwarding is not automatic." -ForegroundColor Yellow
    Write-Host "    Git SSH operations inside Goose may fail. See README: Podman on Windows." -ForegroundColor Yellow

} else {
    # ── Nothing found — give a clear diagnostic ───────────────────────────────
    if ($_dockerCmd) {
        Write-Host "XX  Docker found but daemon is not running — start Docker Desktop." -ForegroundColor Red
    } elseif ($_podmanCmd) {
        Write-Host "XX  Podman found but not running — run: podman machine start" -ForegroundColor Red
    } else {
        Write-Host "XX  Neither docker nor podman found on PATH." -ForegroundColor Red
        Write-Host "    Install Docker Desktop or Podman Desktop and try again." -ForegroundColor Red
    }
    exit 1
}
