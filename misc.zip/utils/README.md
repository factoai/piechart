# factoai — Local Developer Platform

This repository contains the tooling needed to run an AI-assisted development environment both **locally** (Docker Compose) and **on AWS** (ECS Fargate).

## Layout

```
~/factoai/
├── enterprisetools/              # Shared infrastructure — start this first (local)
│   ├── docker-compose.yml        # SonarQube + DB, Loki, Promtail, Grafana, Grafana-MCP
│   ├── .env                      # GRAFANA_ADMIN_PASSWORD
│   ├── README.md
│   └── grafana/
│       ├── loki-config.yaml
│       ├── promtail-config.yaml
│       └── provisioning/
│           └── datasources/
│               └── loki.yaml
├── cofy/                         # Goose AI agent
│   ├── docker-compose.yml        # Local: Goose + semgrep-mcp, attaches to enterprisetools network
│   ├── .env                      # API keys and tokens (local mode)
│   ├── README.md
│   ├── workspace/                # Mount your project source code here
│   │   ├── goose.md              # Session-start behaviour instructions for Goose
│   │   └── context.md            # Platform knowledge injected into every turn (via TOM)
│   ├── goose/
│   │   └── config.yaml           # MCP extension definitions
│   ├── goose-data/               # Chatrecall persistence (local — gitignored)
│   └── terraform/                # AWS infrastructure (Terraform)
│       ├── tf                    # Docker wrapper — runs Terraform without a local install
│       ├── bootstrap/            # One-time S3 state bucket + Secrets Manager secret
│       ├── environments/
│       │   └── dev/              # Dev environment root module
│       └── modules/
│           ├── vpc/
│           ├── aurora/
│           ├── ecs/
│           ├── chatrecall-mcp/
│           └── goose-agent/
├── chatrecall-mcp/               # chatrecall MCP server (Python/FastMCP + pgvector)
│   ├── src/
│   ├── migrations/
│   └── Dockerfile
├── push-images.sh                # Build and push ECR images (chatrecall-mcp, goose-agent)
└── cofy/
    └── aws-start-session.sh      # Launch on-demand Fargate task + ECS Exec TTY session
```

## Stacks

### [`enterprisetools/`](./enterprisetools/README.md)

Shared developer tooling. Provides static code analysis (SonarQube) and log observability (Grafana/Loki), both exposed to Goose via MCP servers.

| Service | Port | Purpose |
|---|---|---|
| SonarQube | `9000` | Static code analysis |
| Loki | `3100` | Log aggregation and storage |
| Promtail | — | Scrapes Docker container logs → Loki |
| Grafana | `3000` | Log and metrics visualization |
| Grafana MCP | `8000` | MCP (SSE) bridge for AI agents |

### [`cofy/`](./cofy/README.md)

Goose AI agent, pre-wired to the enterprise tools via MCP extensions:

| Extension | Transport | Capability |
|---|---|---|
| SonarQube MCP | stdio | Query code quality issues, metrics, and analysis results |
| Grafana MCP | SSE | Read application logs from Loki, explore dashboards |
| Semgrep MCP | streamable_http | Scan source code for security vulnerabilities |
| chatrecall MCP | streamable_http | Store and search previous session knowledge |

### [`cofy/terraform/`](./cofy/terraform/README.md)

AWS infrastructure for running a Goose agent farm on ECS Fargate, backed by Aurora Serverless v2 for shared chatrecall memory. See the Terraform README for the architecture diagram and deployment instructions.

## Platform Scripts

| Platform | Startup | Shutdown |
|---|---|---|
| macOS / Linux | `./local-startup.sh` | `./shutdown.sh` |
| Windows | `.\win\local-startup.ps1` | `.\win\shutdown.ps1` |

Both sets of scripts share the same logic. The PowerShell scripts live in `win/` and require no additional modules — only built-in PowerShell cmdlets and `docker`/`podman` on `PATH`.

### Windows — first-time PowerShell setup

By default, Windows blocks unsigned scripts. Run once in an **elevated** PowerShell:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

### Windows — SSH agent prerequisite

The OpenSSH Authentication Agent service must be running for git SSH operations inside Goose. Run once in an **elevated** PowerShell:

```powershell
Set-Service -Name ssh-agent -StartupType Automatic
Start-Service ssh-agent
ssh-add ~\.ssh\id_ed25519
```

`local-startup.ps1` checks the service state on every run and warns if it is stopped.

## Container Engine — Docker or Podman

`local-startup.sh` and `shutdown.sh` work with either Docker or Podman. The `docker-compat.sh` wrapper auto-detects which engine is running and sets the correct socket path and compose command — no manual configuration needed for Docker.

### Docker (default)

Install [Docker Desktop](https://www.docker.com/products/docker-desktop/) and start it. The scripts detect it automatically.

### Podman

Install [Podman Desktop](https://podman-desktop.io/) and start the Podman machine:

```bash
podman machine init   # first time only
podman machine start
```

The scripts detect Podman automatically and use `podman compose` with the correct socket.

> **Podman on macOS — SSH agent limitation:**
> Docker Desktop forwards the macOS SSH agent into its VM automatically. Podman does not.
> Git SSH operations inside the Goose container (push/pull) will fail unless you manually forward your key into the Podman VM:
>
> ```bash
> # Add key to the Podman VM's agent
> podman machine ssh ssh-add ~/.ssh/id_ed25519
> ```
>
> This must be repeated after each `podman machine stop` / `podman machine start`.

### Rollback and checkpoint commands

If you need to run container commands directly (e.g. to roll back a checkpoint), use whichever engine is active:

```bash
# Docker
docker tag cofy-goose:checkpoint-20260402-143000 cofy-goose:local
docker images cofy-goose

# Podman
podman tag cofy-goose:checkpoint-20260402-143000 cofy-goose:local
podman images cofy-goose
```

## Quick Start — Local

Use `local-startup.sh` and `shutdown.sh` from the `utils/` repo. They handle service ordering, SonarQube readiness, and automatically checkpoint and save the Goose container image between sessions.

```bash
# Start everything and launch Goose
./local-startup.sh

# After exiting Goose, commit the session to persist any installed software
./shutdown.sh
```

### How image persistence works

The Goose container runs as a non-root user but has full `sudo` access, so Goose can install packages and tools freely during a session. Because installed software lives in the container filesystem (not a volume), it would be lost when the container is removed — unless you commit it.

`local-startup.sh` and `shutdown.sh` automate this:

| Step | What happens |
|---|---|
| `./local-startup.sh` | Tags the current `cofy-goose:local` as `cofy-goose:checkpoint-YYYYMMDD-HHMMSS`, then starts the session container as `cofy-goose-session` (without `--rm`) |
| Goose session | Install anything — `sudo apt-get install …`, `pip install …`, etc. |
| Exit Goose | Type `exit` inside the session; the container stops but is not removed |
| `./shutdown.sh` | Commits `cofy-goose-session` → `cofy-goose:local`, then removes the container |

Next `./local-startup.sh` picks up `cofy-goose:local` with all your installed software intact.

**To roll back to a checkpoint:**

```bash
docker tag cofy-goose:checkpoint-20260402-143000 cofy-goose:local   # Docker
podman tag cofy-goose:checkpoint-20260402-143000 cofy-goose:local   # Podman
```

**To list available checkpoints:**

```bash
docker images cofy-goose   # Docker
podman images cofy-goose   # Podman
```

## 🛠 Podman on Apple Silicon: Troubleshooting Guide

If you are experiencing "silent hangs" or permission errors while using Podman on M1/M2/M3 Macs, follow these steps to stabilize your environment.

---

### 1. Issue: CLI Hangs (Infinite Silent Wait)
**Symptom:** Commands like `podman info` or `podman run` hang indefinitely without output.  
**Cause:** The `libkrun` VM type often deadlocks the SSH/Socket handshake on Apple Silicon during the boot process.  
**Solution:** Switch to the native macOS `applehv` (Apple Hypervisor) provider.

#### **Fix Commands:**

```bash
# 1. Force-kill any deadlocked virtualization processes
sudo pkill -9 vmd
pkill -9 -f "podman"

# 2. Remove the unstable machine
podman machine rm -f podman-machine-default

# 3. Re-initialize with the stable Apple Hypervisor
# Note: Using even-numbered CPU counts (4, 6, 8) aligns better with Apple Silicon clusters.
CONTAINERS_MACHINE_PROVIDER=applehv podman machine init --cpus 6 --memory 4096 --disk-size 20

# 4. Start the machine
podman machine start

### Troubleshooting

#### All containers exited after Podman machine restart

**Symptom:** `podman ps -a` shows all containers as `Exited (0)`, some with a nonsensical timestamp like "292 years ago".

**Cause:** The Podman `libkrun` VM (default on Apple Silicon) becomes unresponsive or is stopped, which terminates all running containers. The incorrect timestamp is a cosmetic clock-drift bug in libkrun — harmless.

**Fix:** Restart the machine and re-run the startup script:

```bash
podman machine start
./local-startup.sh
```

`compose up -d` is idempotent — it restarts exited containers and leaves running ones alone.

---

#### `podman` CLI commands hang (Apple Silicon)

**Symptom:** `podman ps`, `podman info`, `podman compose` and other CLI commands hang indefinitely. Podman Desktop may show containers as running.

**Cause:** The default `libkrun` VM type on Apple Silicon uses a non-standard hypervisor whose SSH connection becomes unresponsive, blocking all CLI communication with the machine.

**Fix — switch to `applehv` VM type (recommended, permanent):**

```bash
podman machine stop
podman machine rm
podman machine init --vm-type applehv
podman machine start
```

`applehv` uses Apple's Hypervisor framework with a stable SSH connection. All `podman` CLI commands work reliably. Note: this recreates the machine, so any images or volumes in the old machine will be lost.

**Temporary fix — restart the machine:**

```bash
podman machine stop
podman machine start
```

This may restore connectivity temporarily but the issue can recur.

---

### Docker CLI connects to Podman (no `CONTAINER_ENGINE=podman` needed)

When `podman machine start` runs, it binds a Docker-compatible API socket at `/var/run/docker.sock` and prints:

```
API forwarding listening on: /var/run/docker.sock
Docker API clients default to this address. You do not need to set DOCKER_HOST.
```

This means the standard `docker` CLI and `docker compose` work transparently against Podman. The `local-startup.sh` script auto-detects this — you do not need to set `CONTAINER_ENGINE=podman` unless you want to explicitly force the Podman code path.

---

### Grafana healthcheck EOF with Podman (`dependency failed to start`)

**Symptom:**
```
✘ Container cofy-grafana  Error dependency grafana failed to start
error during connect: ... EOF
Executing external compose provider "/usr/local/bin/docker-compose"
```

**Cause:** `podman compose` is delegating to the old `docker-compose` v1 standalone binary. The v1 binary drops the Podman API socket connection during long healthcheck polling (Grafana's healthcheck waits ~20 seconds).

**Fix (built-in):** `docker-compat.sh` now automatically prefers `docker compose` (v2 plugin) over `podman compose` when both are available. The v2 plugin handles Podman's Docker-compatible API correctly.

If you see this error you may be running an older version of the scripts. Update and re-run:

```bash
CONTAINER_ENGINE=podman ./utils/local-startup.sh
```

You should see `using docker compose (v2) as compose provider for Podman` in the preflight output, confirming the v2 path is active.

---

### SonarQube timeout on first boot

SonarQube takes up to 2 minutes to initialise its database on first run. The startup script polls every 10 seconds for up to 3 minutes. If it times out, check the logs:

```bash
# Docker
docker compose -f enterprisetools/docker-compose.yml logs sonarqube --tail 50

# Podman
DOCKER_HOST=unix:///var/run/docker.sock docker compose -f enterprisetools/docker-compose.yml logs sonarqube --tail 50
```

---

### SSH agent has no loaded keys

**Symptom:** Warning during startup: `SSH agent has no loaded keys`.

**Fix:**

```bash
ssh-add ~/.ssh/id_ed25519
```

On macOS the launchd SSH agent socket path changes on every reboot. `local-startup.sh` detects the current path automatically and updates `cofy/.env` — no manual action needed.

---

## Quick Start — AWS

Prerequisites: AWS credentials configured locally (`~/.aws`), ECR images pushed.

```bash
# 1. Provision AWS infrastructure (first time only)
cd ~/factoai/cofy/terraform/bootstrap && ../../tf init && ../../tf apply
cd ~/factoai/cofy/terraform/environments/dev && ../../tf init && ../../tf apply

# 2. Populate secrets in Secrets Manager
aws secretsmanager put-secret-value \
  --secret-id goose/credentials \
  --secret-string '{"anthropic_api_key":"sk-ant-...","sonarqube_token":"squ_...","grafana_service_account_token":"glsa_..."}' \
  --region us-east-1 --profile default

# 3. Build and push images
cd ~/factoai && ./push-images.sh both

# 4. Start an interactive Goose session on Fargate
cd ~/factoai/cofy && ./aws-start-session.sh
```

Refer to each component's own README for full configuration and troubleshooting details.
