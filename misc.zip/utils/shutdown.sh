#!/usr/bin/env bash
# shutdown.sh — Commits the Goose session container to cofy-goose:local.
#
# Run this after exiting a Goose session started with startup.sh.
# The container (cofy-goose-session) is left behind by startup.sh so this
# script can snapshot it before removing it.
#
# Usage: ./shutdown.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=docker-compat.sh
source "$SCRIPT_DIR/docker-compat.sh" || exit 1

CONTAINER="cofy-goose-session"

# ── Colour helpers ─────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
WHITE='\033[0;97m'
BOLD='\033[1m'
NC='\033[0m'

log()   { echo -e "${CYAN}▶${NC} ${WHITE}$*${NC}"; }
ok()    { echo -e "${GREEN}✔${NC} ${WHITE}$*${NC}"; }
warn()  { echo -e "${YELLOW}⚠${NC}  ${YELLOW}$*${NC}"; }
err()   { echo -e "${RED}✘${NC} ${RED}$*${NC}" >&2; }
banner(){ echo -e "\n${BOLD}${WHITE}$*${NC}"; }

banner "── Shutdown — commit Goose session ───────────────────────────────────"

# ── Verify the session container exists ───────────────────────────────────────
if ! $CONTAINER_ENGINE container inspect "$CONTAINER" &>/dev/null; then
    err "Container '$CONTAINER' not found."
    err "Either startup.sh was not used, the container was already removed, or shutdown.sh already ran."
    exit 1
fi

STATE=$($CONTAINER_ENGINE container inspect --format '{{.State.Status}}' "$CONTAINER")
if [ "$STATE" = "running" ]; then
    warn "Container is still running. Stop the Goose session first (type 'exit' inside goose)."
    exit 1
fi

# ── Commit session → cofy-goose:local ─────────────────────────────────────────
log "Committing $CONTAINER → cofy-goose:local ..."
$CONTAINER_ENGINE commit \
    --format docker \
    --message "goose session $(date +%Y-%m-%dT%H:%M:%S)" \
    "$CONTAINER" \
    cofy-goose:local
ok "cofy-goose:local updated."

# ── Remove the spent session container ────────────────────────────────────────
log "Removing session container..."
$CONTAINER_ENGINE rm "$CONTAINER"
ok "Container removed."

echo ""
ok "Done. Your installed software is baked into cofy-goose:local."
ok "Next startup.sh will checkpoint it before the next session."
