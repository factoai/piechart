#!/usr/bin/env bash
# startup.sh — Brings up the full local developer platform.
#
# Steps:
#   1. Start the enterprisetools shared infrastructure stack
#   2. Wait for SonarQube, then prompt for a token if one is not yet set
#   3. Start semgrep-mcp and launch the Goose CLI
#
# Usage: ./startup.sh [--no-checkpoint]
#   --no-checkpoint  Skip tagging cofy-goose:local as a checkpoint image

set -euo pipefail

NO_CHECKPOINT=false
REMAINING_ARGS=()
for arg in "$@"; do
    case "$arg" in
        --no-checkpoint) NO_CHECKPOINT=true ;;
        *) REMAINING_ARGS+=("$arg") ;;
    esac
done
set -- "${REMAINING_ARGS[@]+"${REMAINING_ARGS[@]}"}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ENTERPRISETOOLS_DIR="$ROOT_DIR/enterprisetools"
COFY_DIR="$ROOT_DIR/cofy"
COFY_ENV="$COFY_DIR/.env"

# ── Colour helpers ─────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
WHITE='\033[0;97m'
BOLD='\033[1m'
NC='\033[0m'

log()    { echo -e "${CYAN}▶${NC} ${WHITE}$*${NC}"; }
ok()     { echo -e "${GREEN}✔${NC} ${WHITE}$*${NC}"; }
warn()   { echo -e "${YELLOW}⚠${NC}  ${YELLOW}$*${NC}"; }
err()    { echo -e "${RED}✘${NC} ${RED}$*${NC}" >&2; }
plain()  { echo -e "  ${WHITE}$*${NC}"; }
banner() { echo -e "\n${BOLD}${WHITE}$*${NC}"; }

# ── Preflight checks ───────────────────────────────────────────────────────────
banner "── Preflight ─────────────────────────────────────────────────────────"

# Detect Docker vs Podman and export CONTAINER_ENGINE / COMPOSE_CMD / DOCKER_SOCKET
# shellcheck source=docker-compat.sh
source "$SCRIPT_DIR/docker-compat.sh" || exit 1

if [ ! -f "$COFY_ENV" ]; then
    err "cofy/.env not found at $COFY_ENV"
    exit 1
fi

ok "${CONTAINER_ENGINE} is running."

# ── SSH keys ───────────────────────────────────────────────────────────────────
# Mount ~/.ssh read-only into the container so git can authenticate without
# needing an SSH agent socket. Works for both Docker and Podman on macOS.
if [[ "$(uname)" == "Darwin" ]]; then
    if grep -q '^SSH_KEYS_DIR=' "$COFY_ENV" 2>/dev/null; then
        sed -i '' "s|^SSH_KEYS_DIR=.*|SSH_KEYS_DIR=${HOME}/.ssh|" "$COFY_ENV"
    else
        echo "SSH_KEYS_DIR=${HOME}/.ssh" >> "$COFY_ENV"
    fi
    if [ -f "${HOME}/.ssh/id_ed25519" ] || [ -f "${HOME}/.ssh/id_rsa" ]; then
        ok "SSH keys ready (${HOME}/.ssh mounted into container)."
    else
        warn "No SSH key found at ~/.ssh/id_ed25519 or ~/.ssh/id_rsa — git SSH operations may fail."
    fi
fi

# Validate ANTHROPIC_API_KEY
ANTHROPIC_API_KEY_VAL="$(grep -E '^ANTHROPIC_API_KEY=' "$COFY_ENV" | cut -d'=' -f2- | tr -d '[:space:]')"

if [ -z "$ANTHROPIC_API_KEY_VAL" ] || [ "$ANTHROPIC_API_KEY_VAL" = "your_anthropic_api_key_here" ]; then
    err "ANTHROPIC_API_KEY is not set in cofy/.env."
    err "Add your key from https://console.anthropic.com/ and re-run."
    exit 1
fi

log "Validating Anthropic API key..."
HTTP_STATUS=$(curl -sf -o /dev/null -w "%{http_code}" \
    -H "x-api-key: $ANTHROPIC_API_KEY_VAL" \
    -H "anthropic-version: 2023-06-01" \
    "https://api.anthropic.com/v1/models" 2>/dev/null || echo "000")

case "$HTTP_STATUS" in
    200) ok "Anthropic API key is valid." ;;
    401) err "Anthropic API key is invalid (401 Unauthorized)."
         err "Update ANTHROPIC_API_KEY in cofy/.env and re-run."
         exit 1 ;;
    403) err "Anthropic API key does not have permission to access this resource (403 Forbidden)."
         err "Check your key's permissions at https://console.anthropic.com/"
         exit 1 ;;
    000) warn "Could not reach api.anthropic.com — no internet connection or API is down."
         warn "Continuing anyway; Goose will fail if the API is unreachable." ;;
    *)   warn "Unexpected response from Anthropic API (HTTP $HTTP_STATUS) — continuing anyway." ;;
esac

# ── Step 1: Start enterprisetools ─────────────────────────────────────────────
banner "── Step 1 of 3 — Start shared infrastructure ─────────────────────────"

# Check if the stack's ports are already bound by a different container engine.
# Ports: SonarQube=9000, Grafana=3000, Loki=3100
_ports_bound_by_other_engine() {
    local our_containers
    our_containers=$($COMPOSE_CMD -f "$ENTERPRISETOOLS_DIR/docker-compose.yml" ps -q 2>/dev/null | wc -l | tr -d ' ') || our_containers=0
    [ "$our_containers" -gt 0 ] && return 1  # ports are ours — not a conflict
    for port in 9000 3000 3100; do
        if lsof -iTCP:"$port" -sTCP:LISTEN &>/dev/null 2>&1; then
            return 0
        fi
    done
    return 1
}

if _ports_bound_by_other_engine; then
    warn "enterprisetools ports (9000/3000/3100) are already bound by a different container engine."
    warn "Stop the existing stack first, then re-run:"
    warn "  docker compose -f enterprisetools/docker-compose.yml down"
    exit 1
fi

# compose up -d is idempotent — starts missing containers, leaves running ones alone.
log "Starting enterprisetools stack (SonarQube, Loki, Promtail, Grafana, Grafana-MCP)..."
$COMPOSE_CMD -f "$ENTERPRISETOOLS_DIR/docker-compose.yml" up -d
ok "enterprisetools services started."

# ── Step 2: Wait for SonarQube and configure token ────────────────────────────
banner "── Step 2 of 3 — Wait for SonarQube and configure token ──────────────"

log "Waiting for SonarQube to become operational (this takes ~2 minutes on first boot)..."

MAX_WAIT=180
INTERVAL=10
ELAPSED=0

while true; do
    STATUS=$(curl -sf "http://localhost:9000/api/system/status" 2>/dev/null \
        | grep -o '"status":"[^"]*"' | cut -d'"' -f4 || true)

    if [ "$STATUS" = "UP" ]; then
        ok "SonarQube is operational."
        break
    fi

    if [ "$ELAPSED" -ge "$MAX_WAIT" ]; then
        err "SonarQube did not become healthy within ${MAX_WAIT}s."
        err "Check logs with: $COMPOSE_CMD -f enterprisetools/docker-compose.yml logs sonarqube"
        exit 1
    fi

    log "  Status: '${STATUS:-starting}' — checking again in ${INTERVAL}s (${ELAPSED}s / ${MAX_WAIT}s)"
    sleep "$INTERVAL"
    ELAPSED=$((ELAPSED + INTERVAL))
done

# Check whether SONARQUBE_TOKEN already holds a real value
CURRENT_TOKEN="$(grep -E '^SONARQUBE_TOKEN=' "$COFY_ENV" | cut -d'=' -f2- | tr -d '[:space:]')"

if [ -z "$CURRENT_TOKEN" ] || [ "$CURRENT_TOKEN" = "your_sonarqube_token_here" ]; then
    warn "SONARQUBE_TOKEN is not yet set in cofy/.env."
    echo ""
    plain "To generate a token:"
    plain "  1. Open http://localhost:9000  (default login: admin / admin)"
    plain "  2. My Account → Security → Generate Token"
    plain "  3. Type: User Token  |  Name: goose-mcp  → click Generate"
    echo ""

    read -rsp $'  \033[0;97mPaste your SonarQube token and press Enter:\033[0m ' INPUT_TOKEN </dev/tty
    echo ""

    if [ -z "$INPUT_TOKEN" ]; then
        err "No token entered. Set SONARQUBE_TOKEN in cofy/.env manually and re-run startup.sh."
        exit 1
    fi

    # Write the token into cofy/.env (BSD sed — macOS compatible)
    sed -i '' "s|^SONARQUBE_TOKEN=.*|SONARQUBE_TOKEN=${INPUT_TOKEN}|" "$COFY_ENV"
    ok "SONARQUBE_TOKEN saved to cofy/.env."
else
    ok "SONARQUBE_TOKEN is already configured."
fi

# ── Step 3: Start Goose ────────────────────────────────────────────────────────
banner "── Step 3 of 3 — Start Goose ─────────────────────────────────────────"

log "Starting semgrep-mcp..."
$COMPOSE_CMD -f "$COFY_DIR/docker-compose.yml" up -d semgrep-mcp
ok "semgrep-mcp is running."

GOOSE_VERSION=$($CONTAINER_ENGINE run --rm cofy-goose:local --version 2>/dev/null | tr -d '\n' || true)
GOOSE_PROVIDER=$(grep -E '^GOOSE_PROVIDER=' "$COFY_ENV" | cut -d'=' -f2- | tr -d '[:space:]')
GOOSE_MODEL=$(grep -E '^GOOSE_MODEL=' "$COFY_ENV" | cut -d'=' -f2- | tr -d '[:space:]')

# ── Checkpoint: snapshot the current image before the session ──────────────────
# This lets you roll back if a session goes sideways.
#   docker tag cofy-goose:checkpoint-YYYYMMDD-HHMMSS cofy-goose:local  # to roll back
if $NO_CHECKPOINT; then
    warn "Skipping image checkpoint (--no-checkpoint)."
else
    CHECKPOINT_TAG="checkpoint-$(date +%Y%m%d-%H%M%S)"
    if $CONTAINER_ENGINE image inspect cofy-goose:local &>/dev/null; then
        $CONTAINER_ENGINE tag cofy-goose:local "cofy-goose:${CHECKPOINT_TAG}"
        ok "Image checkpoint saved: cofy-goose:${CHECKPOINT_TAG}"
    else
        warn "cofy-goose:local image not found — skipping checkpoint."
    fi
fi

echo ""
ok "All services are up. Launching Goose CLI..."
ok "  Version  : ${GOOSE_VERSION:-unknown}"
ok "  Provider : $GOOSE_PROVIDER"
ok "  Model    : $GOOSE_MODEL"
echo ""

# ── Launch mode ────────────────────────────────────────────────────────────────
# ./startup.sh                  → interactive session (run shutdown.sh when done)
# ./startup.sh "install rg fd"  → one-shot instruction; auto-commits on return
INSTRUCTION="${1:-}"

# Remove any stale cofy-goose-session container left from a previous run
# (e.g. if shutdown.sh was skipped or the session crashed).
if $CONTAINER_ENGINE container inspect cofy-goose-session &>/dev/null 2>&1; then
    warn "Stale cofy-goose-session container found — removing before starting new session."
    $CONTAINER_ENGINE rm -f cofy-goose-session
fi

if [ -n "$INSTRUCTION" ]; then
    # One-shot mode: run a single instruction, then auto-commit the result.
    ok "One-shot mode: \"$INSTRUCTION\""
    echo ""
    $COMPOSE_CMD -f "$COFY_DIR/docker-compose.yml" run \
        --name cofy-goose-session goose run --text "$INSTRUCTION"
    log "Instruction complete. Committing container → cofy-goose:local ..."
    $CONTAINER_ENGINE commit \
        --format docker \
        --message "one-shot: $INSTRUCTION ($(date +%Y-%m-%dT%H:%M:%S))" \
        cofy-goose-session cofy-goose:local
    $CONTAINER_ENGINE rm cofy-goose-session
    ok "cofy-goose:local updated."
else
    # Interactive mode: container persists after exit so shutdown.sh can commit it.
    plain "When done, run ./shutdown.sh to commit the session and update cofy-goose:local."
    echo ""
    # --name gives shutdown.sh a stable container name to commit.
    # No --rm so the container persists after exit for shutdown.sh to snapshot.
    $COMPOSE_CMD -f "$COFY_DIR/docker-compose.yml" run --name cofy-goose-session goose session
fi
