# enterprisetools — Claude Code Context

## What this is

Shared developer tooling infrastructure. Owns the `enterprisetools` Docker bridge network. The `cofy/` stack attaches to this network as an external consumer.

## Services

| Container | Image | Port | Purpose |
|---|---|---|---|
| `cofy-sonarqube-db` | `postgres:15` | internal | SonarQube backing DB |
| `cofy-sonarqube` | `sonarqube:community` | `9000` | Static code analysis |
| `cofy-loki` | `grafana/loki:latest` | `3100` | Log aggregation |
| `cofy-promtail` | `grafana/promtail:latest` | — | Scrapes all Docker container logs → Loki |
| `cofy-grafana` | `grafana/grafana:latest` | `3000` | Dashboards and log explorer |
| `cofy-grafana-mcp` | `grafana/mcp-grafana:latest` | `8000` | MCP SSE bridge for AI agents |

## Key config files

```
enterprisetools/
├── docker-compose.yml
├── .env                                  # GRAFANA_ADMIN_PASSWORD (never commit)
└── grafana/
    ├── loki-config.yaml
    ├── promtail-config.yaml
    └── provisioning/datasources/loki.yaml   # auto-provisions Loki in Grafana on first boot
```

## Gotchas

- Loki uses a distroless image — no shell, no healthcheck available. It will show as `running` not `healthy`.
- SonarQube requires `vm.max_map_count >= 524288`. On macOS with Docker Desktop this is handled automatically.
- `grafana-mcp` must start **after** Grafana is healthy — restart it if it returns auth errors on first boot: `docker compose restart grafana-mcp`.
- Grafana MCP is **SSE-only** — always `type: sse` in `goose/config.yaml`, URL `http://grafana-mcp:8000/sse`.
- Promtail discovers all Docker containers automatically via the Docker socket. Log labels: `container`, `service`, `stream`, `project`, `level`.

## First-time setup

1. `docker compose up -d` and wait ~2 min for SonarQube
2. Open http://localhost:9000, log in (`admin`/`admin`), change password
3. **My Account → Security → Generate Token** (type: User Token, name: `goose-mcp`)
4. Copy token → `cofy/.env` as `SONARQUBE_TOKEN` (local) or into `goose/credentials` Secrets Manager secret (AWS)
5. Grafana service account token (optional but recommended): http://localhost:3000 → Administration → Service Accounts → Add → Viewer role → Add token → copy to `cofy/.env` as `GRAFANA_SERVICE_ACCOUNT_TOKEN`

## Network

The `enterprisetools` Docker bridge network must exist before `cofy/` starts. External stacks reference it as:

```yaml
networks:
  enterprisetools:
    external: true
```

Containers reachable by name on this network: `sonarqube`, `grafana`, `grafana-mcp`, `loki`, `promtail`.
