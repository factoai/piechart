# enterprisetools — Shared Infrastructure Stack

This stack provides the shared developer tooling infrastructure used by local AI agents and development workflows. It runs SonarQube for static code analysis and a Grafana/Loki observability stack for log aggregation and visualization.

All services share a Docker network named `enterprisetools`, which external stacks (such as `cofy`) attach to in order to reach these services by container name.

## Services

| Container | Image | Port | Purpose |
|---|---|---|---|
| `cofy-sonarqube-db` | `postgres:15` | internal | Backing database for SonarQube |
| `cofy-sonarqube` | `sonarqube:community` | `9000` | Static code analysis server |
| `cofy-loki` | `grafana/loki:latest` | `3100` | Log aggregation and storage backend |
| `cofy-promtail` | `grafana/promtail:latest` | — | Scrapes all Docker container logs and ships them to Loki |
| `cofy-grafana` | `grafana/grafana:latest` | `3000` | Visualization UI — dashboards, log explorer |
| `cofy-grafana-mcp` | `grafana/mcp-grafana:latest` | `8000` | MCP server (SSE) — exposes Grafana and Loki to AI agents |

## Prerequisites

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) — Docker Compose v2 is included
- At least **5 GB of free RAM** (SonarQube requires ~3 GB on its own)
- macOS: no extra configuration needed
- Linux: set the kernel parameter required by SonarQube (see [Troubleshooting](#troubleshooting))

## Project Layout

```
enterprisetools/
├── docker-compose.yml
├── .env                                    # Grafana admin password
└── grafana/
    ├── loki-config.yaml                    # Loki storage and schema settings
    ├── promtail-config.yaml                # Log scraping rules and label pipeline
    └── provisioning/
        └── datasources/
            └── loki.yaml                   # Auto-provisions Loki in Grafana on first boot
```

## Setup and Usage

### 1. Configure environment variables

Open `.env` and set the Grafana admin password (the default `admin` is fine for local use):

```env
GRAFANA_ADMIN_PASSWORD=admin
```

### 2. Start the stack

```bash
cd enterprisetools
docker compose up -d
```

SonarQube takes approximately **2 minutes** to become operational on first boot. Watch its progress:

```bash
docker compose logs -f sonarqube
```

Wait until you see: `SonarQube is operational`

### 3. Verify all services are healthy

```bash
docker compose ps
```

All services should show `healthy` or `running`.

### Stop the stack

```bash
docker compose down
```

To also remove all persisted data (SonarQube history, Grafana dashboards, Loki logs):

```bash
docker compose down -v
```

### Restart a single service

```bash
docker compose restart grafana-mcp
```

### View logs for a service

```bash
docker compose logs -f grafana
docker compose logs -f sonarqube
docker compose logs -f loki
docker compose logs -f promtail
```

## Accessing the UIs

| Service | URL | Default credentials |
|---|---|---|
| SonarQube | [http://localhost:9000](http://localhost:9000) | `admin` / `admin` |
| Grafana | [http://localhost:3000](http://localhost:3000) | `admin` / `admin` |
| Loki (API) | [http://localhost:3100](http://localhost:3100) | none |
| Grafana MCP (SSE) | [http://localhost:8000](http://localhost:8000) | n/a — internal use only |

Both SonarQube and Grafana will prompt you to change the default password on first login.

## SonarQube — First-Time Configuration

After the stack is healthy you need to generate an API token for the Goose MCP extension:

1. Open [http://localhost:9000](http://localhost:9000) and log in (`admin` / `admin`)
2. Change the default password when prompted
3. Go to **My Account → Security → Generate Token**
4. Choose type **User Token**, give it a name (e.g. `goose-mcp`), and click **Generate**
5. Copy the token and paste it into `cofy/.env` as `SONARQUBE_TOKEN` (local mode) or add it to the `goose/credentials` Secrets Manager secret (AWS mode — see [`../cofy/terraform/README.md`](../cofy/terraform/README.md))

## Grafana MCP — Upgrading to a Service Account Token

By default `grafana-mcp` authenticates using the Grafana admin username and password. For better security you can use a service account token instead:

1. Open [http://localhost:3000](http://localhost:3000) and log in
2. Go to **Administration → Service Accounts → Add service account**
3. Name it `goose-mcp`, set the role to **Viewer** (or **Editor** if write access is needed), click **Create**
4. Click **Add service account token**, copy the generated token
5. Update the `grafana-mcp` service in `docker-compose.yml` — replace its `environment` block with:

```yaml
environment:
  GRAFANA_URL: http://grafana:3000
  GRAFANA_SERVICE_ACCOUNT_TOKEN: ${GRAFANA_SERVICE_ACCOUNT_TOKEN}
```

6. Add the variable to `.env`:

```env
GRAFANA_SERVICE_ACCOUNT_TOKEN=glsa_...
```

7. Restart the service:

```bash
docker compose restart grafana-mcp
```

## How Log Collection Works

Promtail automatically discovers every Docker container on the host via the Docker socket. No application-side configuration is required — any container writing to stdout or stderr will have its logs collected and stored in Loki, labelled with:

| Label | Source |
|---|---|
| `container` | Container name |
| `service` | Docker Compose service name |
| `stream` | `stdout` or `stderr` |
| `project` | Docker Compose project name |
| `level` | Parsed from JSON (`level` field) or plain-text patterns (`DEBUG`, `ERROR`, etc.) |

Logs can be explored in Grafana using **Explore → Loki** with LogQL queries such as:

```logql
{service="my-app"} |= "error"
{project="cofy"} | json | level="debug"
{container="cofy-sonarqube"} | line_format "{{.msg}}"
```

## Shared Network

All services are attached to a Docker bridge network named `enterprisetools`. External stacks that need to communicate with these services declare it as an external network:

```yaml
networks:
  enterprisetools:
    external: true
```

Containers on this network can reach services by their container name (e.g., `http://sonarqube:9000`, `http://grafana-mcp:8000`).

## Troubleshooting

### SonarQube fails to start on Linux

SonarQube requires `vm.max_map_count` ≥ 524288. On macOS with Docker Desktop this is handled automatically. On Linux:

```bash
sudo sysctl -w vm.max_map_count=524288
# To persist across reboots:
echo "vm.max_map_count=524288" | sudo tee -a /etc/sysctl.conf
```

### Logs not appearing in Grafana

Check that Promtail started successfully and is connected to Loki:

```bash
docker compose logs promtail
```

Then verify data is flowing by opening **Grafana → Explore**, selecting the **Loki** datasource, and running:

```logql
{project="enterprisetools"}
```

### Grafana MCP returns authentication errors after first boot

The `grafana-mcp` service may start before Grafana has fully initialised. Restart it:

```bash
docker compose restart grafana-mcp
```
