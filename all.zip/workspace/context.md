# Platform Context

You are running as the Goose AI agent inside a Docker container, part of the local developer platform.

## My Environment
- Platform: local dev (Docker)
- SonarQube: http://host.docker.internal:9000
- Grafana: http://grafana:3000
- Workspace: /workspace
- Do not print sensitive data to console such a token, password

## Preferences
- Always confirm before making destructive changes
- Use pnpm, not npm
- Always prefer MCP over API calls

## Network

All services communicate over the `enterprisetools` Docker bridge network. Container hostnames resolve directly by service name.

## Services

| Service | Hostname | Port | Purpose |
|---------|----------|------|---------|
| SonarQube | `host.docker.internal` | `9000` | Static code analysis |
| Grafana | `grafana` | `3000` | Dashboards and log exploration UI |
| Loki | `loki` | `3100` | Log storage backend (queried via Grafana) |
| Promtail | `promtail` | — | Collects Docker container logs and ships to Loki |
| Grafana MCP | `grafana-mcp` | `8000` | MCP server for Grafana/Loki access |
| Semgrep MCP | `semgrep-mcp` | `8000` | MCP server for vulnerability scanning |
| SonarQube DB | `sonarqube-db` | `5432` | Postgres backing SonarQube (internal only) |

## MCP Extensions

| Extension | Transport | Connection | What it does |
|-----------|-----------|------------|--------------|
| sonarqube | stdio | `docker run mcp/sonarqube` | Spawns a transient container to query SonarQube via `host.docker.internal:9000` |
| grafana | sse | `http://grafana-mcp:8000/sse` | Queries Grafana dashboards and Loki logs |
| semgrep | streamable_http | `http://semgrep-mcp:8000/mcp` | Scans source code in `/src` for vulnerabilities |

## Workspace

- Your working directory is `/workspace`
- The same directory is mounted read-only in the Semgrep MCP container at `/src`
- Place or symlink project source code inside `/workspace` before scanning

## Log Labels

Promtail collects logs from all Docker containers on the host and tags them with:
`{service, container, stream, project, level}`

Use these labels in LogQL queries via the Grafana MCP extension.
