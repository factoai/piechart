"""
scraper.py
----------
Reads a JSON file, filters records where status == 'active',
and writes the results to output.csv.
"""

import json
import csv
import sys
import os


def load_json(filepath: str) -> list:
    """Load and parse a JSON file."""
    if not os.path.exists(filepath):
        print(f"[ERROR] File not found: {filepath}")
        sys.exit(1)
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"[INFO] Loaded {len(data)} records from '{filepath}'")
    return data


def filter_active(records: list) -> list:
    """Filter records where status is 'active'."""
    active = [r for r in records if r.get("status", "").lower() == "active"]
    print(f"[INFO] {len(active)} active record(s) found out of {len(records)} total")
    return active


def write_csv(records: list, output_path: str) -> None:
    """Write a list of dictionaries to a CSV file."""
    if not records:
        print("[WARN] No records to write.")
        return

    fieldnames = list(records[0].keys())

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)

    print(f"[INFO] Results written to '{output_path}'")


def main():
    input_file = "data.json"
    output_file = "output.csv"

    records = load_json(input_file)
    active_records = filter_active(records)
    write_csv(active_records, output_file)

    print("\n--- Done! Preview of output ---")
    for row in active_records:
        print(row)


if __name__ == "__main__":
    main()
