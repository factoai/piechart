#!/usr/bin/env python3

import calendar
import sys
from datetime import datetime

MONTH_WIDTH = 22
COLUMN_GAP = "   "


def format_month_lines(year: int, month: int) -> list[str]:
    cal = calendar.TextCalendar(calendar.MONDAY)
    lines = cal.formatmonth(year, month).splitlines()
    # Pad each line to a fixed width
    return [line.ljust(MONTH_WIDTH) for line in lines]


def print_quarter(year: int, months: tuple[int, int, int], quarter: int) -> None:
    col1, col2, col3 = [format_month_lines(year, m) for m in months]

    # Ensure all columns have the same number of lines
    max_lines = max(len(col1), len(col2), len(col3))
    empty = " " * MONTH_WIDTH
    col1 += [empty] * (max_lines - len(col1))
    col2 += [empty] * (max_lines - len(col2))
    col3 += [empty] * (max_lines - len(col3))

    total_width = MONTH_WIDTH * 3 + len(COLUMN_GAP) * 2
    print(f"{'Q' + str(quarter):^{total_width}}")
    print("-" * total_width)

    for l1, l2, l3 in zip(col1, col2, col3):
        print(f"{l1}{COLUMN_GAP}{l2}{COLUMN_GAP}{l3}")

    print()


def print_calendar(year: int) -> None:
    total_width = MONTH_WIDTH * 3 + len(COLUMN_GAP) * 2
    print(f"\n{'=' * total_width}")
    print(f"{'CALENDAR ' + str(year):^{total_width}}")
    print(f"{'=' * total_width}\n")

    quarters = [
        (1,  (1, 2, 3)),
        (2,  (4, 5, 6)),
        (3,  (7, 8, 9)),
        (4,  (10, 11, 12)),
    ]

    for quarter, months in quarters:
        print_quarter(year, months, quarter)


def parse_year(arg: str) -> int:
    try:
        year = int(arg)
        if year < 1 or year > 9999:
            raise ValueError("Year must be between 1 and 9999.")
        return year
    except ValueError as e:
        print(f"Error: Invalid year '{arg}'. {e}")
        sys.exit(1)


def main():
    if len(sys.argv) > 2:
        print("Usage: python3 calendar_app.py [year]")
        sys.exit(1)

    year = parse_year(sys.argv[1]) if len(sys.argv) == 2 else datetime.now().year
    print_calendar(year)


if __name__ == "__main__":
    main()
