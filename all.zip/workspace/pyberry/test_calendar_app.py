#!/usr/bin/env python3

import sys
import unittest
from io import StringIO
from unittest.mock import patch

from calendar_app import (
    COLUMN_GAP,
    MONTH_WIDTH,
    format_month_lines,
    parse_year,
    print_calendar,
    print_quarter,
)


class TestFormatMonthLines(unittest.TestCase):
    """Tests for format_month_lines()"""

    def test_returns_list_of_strings(self):
        lines = format_month_lines(2024, 1)
        self.assertIsInstance(lines, list)
        self.assertTrue(all(isinstance(line, str) for line in lines))

    def test_each_line_padded_to_month_width(self):
        for month in range(1, 13):
            lines = format_month_lines(2024, month)
            for line in lines:
                self.assertEqual(
                    len(line),
                    MONTH_WIDTH,
                    msg=f"Line {repr(line)} for month {month} is not {MONTH_WIDTH} chars wide",
                )

    def test_header_contains_month_name(self):
        month_names = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December",
        ]
        for i, name in enumerate(month_names, start=1):
            lines = format_month_lines(2024, i)
            header = lines[0]
            self.assertIn(name, header, msg=f"Month name '{name}' not found in header: {repr(header)}")

    def test_header_contains_year(self):
        lines = format_month_lines(2024, 6)
        header = lines[0]
        self.assertIn("2024", header)

    def test_week_starts_on_monday(self):
        """The day-header row should start with 'Mo'."""
        lines = format_month_lines(2024, 1)
        day_header = lines[1]
        self.assertTrue(day_header.strip().startswith("Mo"))

    def test_non_empty_output(self):
        lines = format_month_lines(2025, 3)
        self.assertGreater(len(lines), 0)

    def test_all_twelve_months_produce_output(self):
        for month in range(1, 13):
            lines = format_month_lines(2024, month)
            self.assertGreater(len(lines), 0, msg=f"Empty output for month {month}")

    def test_february_leap_year(self):
        """Feb in a leap year (2024) should contain day 29."""
        lines = format_month_lines(2024, 2)
        full_text = "\n".join(lines)
        self.assertIn("29", full_text)

    def test_february_non_leap_year(self):
        """Feb in a non-leap year (2023) should not reach day 29."""
        lines = format_month_lines(2023, 2)
        full_text = "\n".join(lines)
        # Day 29 should not appear as a calendar date
        self.assertNotIn("29", full_text)

    def test_different_years_produce_different_layouts(self):
        """Same month across different years should differ (different start days)."""
        lines_2023 = format_month_lines(2023, 1)
        lines_2024 = format_month_lines(2024, 1)
        self.assertNotEqual(lines_2023, lines_2024)


class TestPrintQuarter(unittest.TestCase):
    """Tests for print_quarter()"""

    def _capture_quarter(self, year, months, quarter):
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            print_quarter(year, months, quarter)
            return mock_stdout.getvalue()

    def test_outputs_quarter_label(self):
        output = self._capture_quarter(2024, (1, 2, 3), 1)
        self.assertIn("Q1", output)

    def test_outputs_correct_quarter_number(self):
        for q, months in [(1, (1, 2, 3)), (2, (4, 5, 6)), (3, (7, 8, 9)), (4, (10, 11, 12))]:
            output = self._capture_quarter(2024, months, q)
            self.assertIn(f"Q{q}", output)

    def test_outputs_all_three_month_names(self):
        output = self._capture_quarter(2024, (1, 2, 3), 1)
        self.assertIn("January", output)
        self.assertIn("February", output)
        self.assertIn("March", output)

    def test_outputs_separator_line(self):
        output = self._capture_quarter(2024, (1, 2, 3), 1)
        self.assertIn("-" * (MONTH_WIDTH * 3 + len(COLUMN_GAP) * 2), output)

    def test_column_gap_present_in_rows(self):
        output = self._capture_quarter(2024, (4, 5, 6), 2)
        # At least one data row should contain the column gap string
        data_rows = output.splitlines()[2:]  # skip Q header and dashes
        self.assertTrue(
            any(COLUMN_GAP in row for row in data_rows),
            msg="COLUMN_GAP not found in any data row",
        )

    def test_each_line_has_expected_total_width(self):
        expected_width = MONTH_WIDTH * 3 + len(COLUMN_GAP) * 2
        output = self._capture_quarter(2024, (1, 2, 3), 1)
        # Skip blank lines and the trailing newline
        data_lines = [line for line in output.splitlines() if line.strip()]
        # Skip the "Q1" header (centred, may be shorter)
        content_lines = data_lines[2:]  # skip Q-label and dashes
        for line in content_lines:
            self.assertEqual(
                len(line),
                expected_width,
                msg=f"Line width mismatch: {len(line)} != {expected_width} for line {repr(line)}",
            )

    def test_ends_with_blank_line(self):
        output = self._capture_quarter(2024, (7, 8, 9), 3)
        self.assertTrue(output.endswith("\n\n"), msg="Quarter output should end with a blank line")


class TestPrintCalendar(unittest.TestCase):
    """Tests for print_calendar()"""

    def _capture_calendar(self, year):
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            print_calendar(year)
            return mock_stdout.getvalue()

    def test_header_contains_calendar_label_and_year(self):
        output = self._capture_calendar(2024)
        self.assertIn("CALENDAR 2024", output)

    def test_header_contains_equals_separator(self):
        output = self._capture_calendar(2024)
        expected_width = MONTH_WIDTH * 3 + len(COLUMN_GAP) * 2
        self.assertIn("=" * expected_width, output)

    def test_all_twelve_month_names_present(self):
        output = self._capture_calendar(2024)
        for name in [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December",
        ]:
            self.assertIn(name, output, msg=f"'{name}' not found in calendar output")

    def test_all_four_quarter_labels_present(self):
        output = self._capture_calendar(2024)
        for q in range(1, 5):
            self.assertIn(f"Q{q}", output)

    def test_output_for_different_years(self):
        output_2023 = self._capture_calendar(2023)
        output_2025 = self._capture_calendar(2025)
        self.assertNotEqual(output_2023, output_2025)

    def test_boundary_year_1(self):
        """Year 1 should not raise an exception."""
        try:
            self._capture_calendar(1)
        except Exception as e:
            self.fail(f"print_calendar(1) raised {e}")

    def test_boundary_year_9999(self):
        """Year 9999 should not raise an exception."""
        try:
            self._capture_calendar(9999)
        except Exception as e:
            self.fail(f"print_calendar(9999) raised {e}")


class TestParseYear(unittest.TestCase):
    """Tests for parse_year()"""

    def test_valid_year_returns_int(self):
        self.assertEqual(parse_year("2024"), 2024)

    def test_valid_year_minimum_boundary(self):
        self.assertEqual(parse_year("1"), 1)

    def test_valid_year_maximum_boundary(self):
        self.assertEqual(parse_year("9999"), 9999)

    def test_valid_year_mid_range(self):
        self.assertEqual(parse_year("2000"), 2000)

    def test_zero_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("0")

    def test_year_too_large_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("10000")

    def test_negative_year_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("-1")

    def test_non_numeric_string_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("abc")

    def test_float_string_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("2024.5")

    def test_empty_string_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("")

    def test_whitespace_string_causes_system_exit(self):
        with self.assertRaises(SystemExit):
            parse_year("   ")

    def test_error_message_printed_on_invalid_year(self):
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            with self.assertRaises(SystemExit):
                parse_year("abc")
            self.assertIn("Error", mock_stdout.getvalue())

    def test_error_message_contains_invalid_value(self):
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            with self.assertRaises(SystemExit):
                parse_year("bad_input")
            self.assertIn("bad_input", mock_stdout.getvalue())


class TestMain(unittest.TestCase):
    """Tests for main() entry point"""

    def _run_main(self, args):
        """Run main() with a fake argv and capture stdout."""
        from calendar_app import main
        with patch("sys.argv", args), patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            main()
            return mock_stdout.getvalue()

    def test_no_args_uses_current_year(self):
        from calendar_app import main
        from datetime import datetime

        current_year = str(datetime.now().year)
        with patch("sys.argv", ["calendar_app.py"]), patch("sys.stdout", new_callable=StringIO) as mock_out:
            main()
            self.assertIn(current_year, mock_out.getvalue())

    def test_explicit_year_arg(self):
        output = self._run_main(["calendar_app.py", "2030"])
        self.assertIn("CALENDAR 2030", output)

    def test_too_many_args_causes_system_exit(self):
        from calendar_app import main
        with patch("sys.argv", ["calendar_app.py", "2024", "extra"]), \
             patch("sys.stdout", new_callable=StringIO):
            with self.assertRaises(SystemExit):
                main()

    def test_too_many_args_prints_usage(self):
        from calendar_app import main
        with patch("sys.argv", ["calendar_app.py", "2024", "extra"]), \
             patch("sys.stdout", new_callable=StringIO) as mock_out:
            with self.assertRaises(SystemExit):
                main()
            self.assertIn("Usage", mock_out.getvalue())

    def test_invalid_year_arg_causes_system_exit(self):
        from calendar_app import main
        with patch("sys.argv", ["calendar_app.py", "not-a-year"]), \
             patch("sys.stdout", new_callable=StringIO):
            with self.assertRaises(SystemExit):
                main()

    def test_out_of_range_year_causes_system_exit(self):
        from calendar_app import main
        with patch("sys.argv", ["calendar_app.py", "99999"]), \
             patch("sys.stdout", new_callable=StringIO):
            with self.assertRaises(SystemExit):
                main()


if __name__ == "__main__":
    unittest.main(verbosity=2)
