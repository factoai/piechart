# pyberry

## Calendar App

A simple command-line calendar application that prints a full year's calendar to the terminal, laid out by quarter with three months displayed side-by-side.

### Features

- Displays all 12 months of a given year, grouped into four quarters (Q1–Q4)
- Each quarter shows three months in a clean, aligned side-by-side layout
- Weeks start on **Monday**
- Correctly handles leap years
- Defaults to the **current year** if no argument is provided

### Usage

```bash
python3 calendar_app.py [year]
```

| Argument | Description |
|----------|-------------|
| `year`   | Optional. A year between 1 and 9999. Defaults to the current year. |

#### Examples

```bash
# Print the calendar for the current year
python3 calendar_app.py

# Print the calendar for a specific year
python3 calendar_app.py 2026
```

#### Sample Output

```
======================================================================================
                                    CALENDAR 2026
======================================================================================

                                        Q1
--------------------------------------------------------------------------------------
January 2026           February 2026          March 2026
Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su
          1  2  3  4                      1                      1
 5  6  7  8  9 10 11    2  3  4  5  6  7  8    2  3  4  5  6  7  8
12 13 14 15 16 17 18    9 10 11 12 13 14 15    9 10 11 12 13 14 15
19 20 21 22 23 24 25   16 17 18 19 20 21 22   16 17 18 19 20 21 22
26 27 28 29 30 31      23 24 25 26 27 28      23 24 25 26 27 28 29
                                              30 31
...
```

### Running Tests

The test suite uses Python's built-in `unittest` framework — no extra dependencies required.

```bash
python3 -m pytest test_calendar_app.py
# or
python3 -m unittest test_calendar_app.py -v
```

### Requirements

- Python 3.9+
- No third-party dependencies (uses only the standard library: `calendar`, `sys`, `datetime`)
