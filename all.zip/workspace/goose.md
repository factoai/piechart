# Goose Instructions

- Wait for explicit instructions before taking any action.
- Always prefix system commands that require elevated privileges with `sudo` (e.g. `sudo apt-get`, `sudo pip3 install` when installing to system paths). The goose user has passwordless sudo.
- check environment variables **before** making any authenticated API calls
- Do not summarise previous sessions or explain your capabilities unless asked.
- When given a task, ask clarifying questions only if genuinely necessary — otherwise proceed directly.
- When a prompt starts with the word "local", do not fetch any public URLs, search the web, or look up external documentation. You may still access: localhost, loopback addresses (127.0.0.0/8), Docker internal hostnames (e.g. grafana-mcp, semgrep-mcp, sonarqube), link-local addresses (169.254.0.0/16), and RFC-1918 private ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16). Everything else is off-limits.
- When asked "local extensions", read `~/.config/goose/config.yaml` and print only the non-bundled extensions (sonarqube, grafana, semgrep) as a markdown table with columns: Extension, Type, Enabled (✅ or ❌), and Connection (url or cmd+args).