# cofy — Claude Code Context

## What this is

Goose AI agent (Block's open-source agent CLI) running locally via Docker Compose, with AWS ECS Fargate support for on-demand agent sessions. All AWS infrastructure is managed by Terraform in `terraform/`.

## Local stack

### Docker Compose services

| Service | Image | Internal hostname | Port |
|---|---|---|---|
| `goose` | custom (see `Dockerfile`) | — | TTY only |
| `semgrep-mcp` | `ghcr.io/semgrep/mcp:latest` | `semgrep-mcp` | **8000** (internal), 8001 (host) |
| `chatrecall-mcp` | local build from `../chatrecall-mcp` | `chatrecall-mcp` | 8000 |

- `enterprisetools` network declared as `external: true` — that stack must be running first
- `./goose-data:/home/goose/.local/share/goose` — chatrecall local persistence (gitignored)
- `./workspace` mounted at `/workspace` (goose) and `/src:ro` (semgrep-mcp)

### MCP extensions (goose/config.yaml)

| Extension | Transport | URL / cmd |
|---|---|---|
| SonarQube | `stdio` | `docker run -i --rm -e SONARQUBE_TOKEN -e SONARQUBE_URL mcp/sonarqube` |
| Grafana MCP | `sse` | `http://grafana-mcp:8000/sse` |
| Semgrep MCP | `streamable_http` | `http://semgrep-mcp:8000/mcp` — port **8000** not 8001 |
| chatrecall MCP | `streamable_http` | `http://chatrecall-mcp:8000/mcp` |

### Gotchas

- Semgrep `docker-compose.yml` maps `8001:8000` (host:container). **Inside Docker network Goose uses port 8000**, not 8001.
- Goose config mounted as **directory** (`./goose:/home/goose/.config/goose`), not a file — Goose rewrites `config.yaml` during sessions.
- Custom `Dockerfile` installs `docker-ce-cli` from Docker's official apt repo — NOT `docker.io` (API version too old).
- Goose container needs `group_add: ["0"]` for Docker socket access.
- `GOOSE_MOIM_MESSAGE_FILE=/workspace/context.md` in `.env` powers the TOM extension (injects `context.md` into every turn).

### Goose session behaviour (workspace/goose.md)

- **`local` prefix** — no public internet; allows localhost, loopback, Docker hostnames, RFC-1918 ranges
- **`local extensions`** — prints non-bundled extensions table from `config.yaml`
- **`status` keyword** — report only, no changes

---

## AWS stack

### Architecture

```
VPC 10.10.0.0/16 (us-east-1)
  Public subnets  1a:10.10.0.0/24  1b:10.10.1.0/24   — NAT Gateway
  Private subnets 1a:10.10.10.0/23 1b:10.10.12.0/23  — ECS Fargate
  DB subnets      1a:10.10.20.0/24 1b:10.10.21.0/24  — Aurora Serverless v2

ECS:
  goose-agent       on-demand task, launched by aws-start-session.sh
  chatrecall-mcp    persistent service, chatrecall-mcp.goose-dev.local:8000

Secrets Manager:
  goose/credentials     anthropic_api_key, sonarqube_token, grafana_service_account_token
  aurora/{name}         DB host/port/user/password (auto-generated, never seen by humans)

ECR: lifecycle policy — keep 3 most recent images, both repos
State: S3 bucket 460385527997-us-east-1-terraform-state, DynamoDB lock terraform-state-lock
```

### IAM

| Role | Grants |
|---|---|
| `ecs-execution-role` | ECR pull, CloudWatch write, both SM secrets read (secrets injected at startup) |
| `goose-task-role` | Nothing — API key arrives as env var |
| `chatrecall-task-role` | `bedrock:InvokeModel` for Titan Embed Text v2 only |

### Terraform

Terraform runs via the `tf` Docker wrapper — no local Terraform install needed:

```bash
cd terraform/environments/dev
../../tf plan      # always review first
../../tf apply     # only after explicit approval
```

The wrapper mounts the entire `terraform/` root so `../../modules/` paths resolve inside the container. AWS profile is always `default`.

### Terraform modules

| Module | What it creates |
|---|---|
| `modules/vpc` | VPC, public/private/DB subnets, NAT GW, IGW, route tables |
| `modules/aurora` | Aurora Serverless v2 (0.5–8 ACU), subnet group, security group, credentials secret |
| `modules/ecs` | ECS cluster, ECR repos + lifecycle policies, security group, IAM roles, log groups |
| `modules/chatrecall-mcp` | ECS Service, task definition, Route53 Service Discovery namespace |
| `modules/goose-agent` | ECS task definition only (no service — launched on demand) |

### Key scripts

- `aws-start-session.sh` — launches on-demand Fargate task, waits for RUNNING, connects via ECS Exec; stops task on exit
- `../push-images.sh chatrecall|goose|both` — build + push to ECR

### First-time setup

```bash
# 1. Bootstrap (once)
cd terraform/bootstrap && ../../tf init && ../../tf apply

# 2. Populate secrets
aws secretsmanager put-secret-value \
  --secret-id goose/credentials \
  --secret-string '{"anthropic_api_key":"sk-ant-...","sonarqube_token":"squ_...","grafana_service_account_token":"glsa_..."}' \
  --region us-east-1 --profile default

# 3. Deploy
cd terraform/environments/dev && ../../tf init && ../../tf apply

# 4. Push images
cd ../.. && ../push-images.sh both
```

---

## Files never to commit

`.env`, `goose-data/`, `terraform/**/.terraform/`, `terraform/**/*.tfstate*`, `terraform/**/*.tfvars`
