#!/usr/bin/env bash
# docker-entrypoint.sh — Egress filtering + selective extension enabling for Goose.
#
# This script runs as root so it can apply iptables egress rules, then drops to
# the goose user before launching goose. It requires:
#   • cap_add: [NET_ADMIN] in docker-compose.yml  (for iptables)
#   • gosu installed in the image                  (for privilege drop)
#
# Egress policy (see squid.conf for the proxy allow-list):
#   • Docker-internal ranges (10/8, 172.16/12, 192.168/16) — always allowed
#   • All other outbound traffic — blocked by iptables; must go via squid proxy
#   • HTTPS_PROXY / HTTP_PROXY env vars route HTTP clients through squid
#   • squid only allows CONNECT to api.anthropic.com:443
#
# Extension selection:
#   docker compose run --rm goose                           # use config.yaml as-is
#   docker compose run -e GOOSE_EXTENSIONS=sonarqube,grafana --rm goose
#   If GOOSE_EXTENSIONS is set, ONLY those extensions are enabled for the session.
#   The original config.yaml is restored on container exit.

set -euo pipefail

CONFIG="/home/goose/.config/goose/config.yaml"

# ── Extension selection (reads config.yaml as goose user) ─────────────────────
# Modify config as root (file is owned by goose but readable/writable to all on
# the config bind mount), restore on exit.
if [ -n "${GOOSE_EXTENSIONS:-}" ]; then
    cp "$CONFIG" "${CONFIG}.bak"
    chown goose:goose "${CONFIG}.bak" 2>/dev/null || true

    echo "▶ docker-entrypoint: enabling extensions: ${GOOSE_EXTENSIONS}"

    # Disable every extension
    yq -i '.extensions[].enabled = false' "$CONFIG"

    # Enable only the requested ones
    IFS=',' read -ra WANTED <<< "$GOOSE_EXTENSIONS"
    for ext in "${WANTED[@]}"; do
        ext="${ext// /}"  # trim any surrounding whitespace
        if yq ".extensions | has(\"${ext}\")" "$CONFIG" | grep -q "true"; then
            yq -i ".extensions.${ext}.enabled = true" "$CONFIG"
            echo "  ✔ ${ext} enabled"
        else
            echo "  ⚠ extension '${ext}' not found in config.yaml — skipping" >&2
        fi
    done

    # Run goose as the goose user. Using gosu instead of exec so this script
    # stays alive after goose exits and can restore the config file.
    gosu goose goose "$@"
    mv "${CONFIG}.bak" "$CONFIG"
else
    # No extension selection — drop directly to goose user and exec goose.
    exec gosu goose goose "$@"
fi
