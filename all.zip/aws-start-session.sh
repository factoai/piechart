#!/usr/bin/env bash
# aws-start-session.sh — Launch an on-demand Goose agent session on ECS Fargate.
#
# Usage: ./aws-start-session.sh [--env dev] [--extensions ext1,ext2,...]
#
#   --env         Terraform environment to read outputs from (default: dev)
#   --extensions  Comma-separated list of Goose extensions to enable.
#                 All others are disabled for this session only.
#                 Example: --extensions sonarqube,grafana,developer,tom
#
# Prerequisites:
#   - AWS CLI v2 with default profile configured
#   - Session Manager Plugin installed (for ECS Exec)
#   - Terraform outputs applied in environments/<env>/

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Colour helpers ─────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
WHITE='\033[0;97m'
BOLD='\033[1m'
NC='\033[0m'

log()    { echo -e "${CYAN}▶${NC} ${WHITE}$*${NC}"; }
ok()     { echo -e "${GREEN}✔${NC} ${WHITE}$*${NC}"; }
warn()   { echo -e "${YELLOW}⚠${NC}  ${YELLOW}$*${NC}"; }
err()    { echo -e "${RED}✘${NC} ${RED}$*${NC}" >&2; }
banner() { echo -e "\n${BOLD}${WHITE}$*${NC}"; }

# ── Args ──────────────────────────────────────────────────────────────────────
ENV="dev"
EXTENSIONS=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --env)        ENV="$2";        shift 2 ;;
        --extensions) EXTENSIONS="$2"; shift 2 ;;
        *) err "Unknown argument: $1"; exit 1 ;;
    esac
done

REGION="us-east-1"
TF_DIR="$SCRIPT_DIR/terraform/environments/$ENV"
TF="$SCRIPT_DIR/terraform/tf"

# ── Preflight ──────────────────────────────────────────────────────────────────
banner "── Preflight ──────────────────────────────────────────────────────────"

if ! command -v aws &>/dev/null; then
    err "AWS CLI not found. Install it from https://aws.amazon.com/cli/ and try again."
    exit 1
fi

if ! command -v docker &>/dev/null; then
    err "Docker not found. Terraform runs via the 'tf' Docker wrapper — start Docker Desktop and try again."
    exit 1
fi

if ! aws sts get-caller-identity --profile default &>/dev/null; then
    err "AWS credentials not configured or expired. Run: aws configure"
    exit 1
fi

ok "AWS credentials valid."

# ── Read Terraform outputs ─────────────────────────────────────────────────────
banner "── Reading Terraform outputs ($ENV) ───────────────────────────────────"

CLUSTER=$(cd "$TF_DIR" && "$TF" output -raw ecs_cluster_name 2>/dev/null)
TASK_DEF=$(cd "$TF_DIR" && "$TF" output -raw goose_task_definition 2>/dev/null)

# Resolve private subnets and security group from AWS directly
VPC_ID=$(cd "$TF_DIR" && "$TF" output -raw vpc_id 2>/dev/null)

SUBNET_IDS=$(aws ec2 describe-subnets \
    --region "$REGION" \
    --profile default \
    --filters "Name=vpc-id,Values=$VPC_ID" "Name=tag:Name,Values=*private*" \
    --query 'Subnets[*].SubnetId' \
    --output text | tr '\t' ',' )

SG_ID=$(aws ec2 describe-security-groups \
    --region "$REGION" \
    --profile default \
    --filters "Name=vpc-id,Values=$VPC_ID" "Name=tag:Name,Values=*ecs-tasks*" \
    --query 'SecurityGroups[0].GroupId' \
    --output text)

ok "Cluster   : $CLUSTER"
ok "Task def  : $TASK_DEF"
ok "Subnets   : $SUBNET_IDS"
ok "Sec group : $SG_ID"
[[ -n "$EXTENSIONS" ]] && ok "Extensions: $EXTENSIONS" || ok "Extensions: (config.yaml defaults)"

# ── Launch Fargate task ────────────────────────────────────────────────────────
banner "── Launching Goose session on ECS Fargate ─────────────────────────────"

# If --extensions was passed, inject GOOSE_EXTENSIONS into the container via
# ECS task overrides. The entrypoint script reads this and enables only those
# extensions, then restores config.yaml when the session ends.
OVERRIDE_ARGS=()
if [[ -n "$EXTENSIONS" ]]; then
    OVERRIDE_JSON=$(printf \
        '{"containerOverrides":[{"name":"goose-agent","environment":[{"name":"GOOSE_EXTENSIONS","value":"%s"}]}]}' \
        "$EXTENSIONS")
    OVERRIDE_ARGS=(--overrides "$OVERRIDE_JSON")
fi

TASK_ARN=$(aws ecs run-task \
    --region "$REGION" \
    --profile default \
    --cluster "$CLUSTER" \
    --task-definition "$TASK_DEF" \
    --launch-type FARGATE \
    --network-configuration "awsvpcConfiguration={subnets=[$SUBNET_IDS],securityGroups=[$SG_ID],assignPublicIp=DISABLED}" \
    --enable-execute-command \
    "${OVERRIDE_ARGS[@]}" \
    --query 'tasks[0].taskArn' \
    --output text)

ok "Task launched: $TASK_ARN"

# ── Wait for task to reach RUNNING ────────────────────────────────────────────
log "Waiting for task to reach RUNNING state..."
aws ecs wait tasks-running \
    --region "$REGION" \
    --profile default \
    --cluster "$CLUSTER" \
    --tasks "$TASK_ARN"

ok "Task is RUNNING."

# ── Open interactive session via ECS Exec ─────────────────────────────────────
banner "── Connecting to Goose session ────────────────────────────────────────"
echo ""

aws ecs execute-command \
    --region "$REGION" \
    --profile default \
    --cluster "$CLUSTER" \
    --task "$TASK_ARN" \
    --container goose-agent \
    --interactive \
    --command "goose session"

# ── Cleanup — stop task when session ends ─────────────────────────────────────
echo ""
log "Session ended. Stopping Fargate task..."
aws ecs stop-task \
    --region "$REGION" \
    --profile default \
    --cluster "$CLUSTER" \
    --task "$TASK_ARN" \
    --reason "Session ended by user" \
    > /dev/null

ok "Task stopped. Goodbye."
