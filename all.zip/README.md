# cofy — Goose AI Agent

Runs [Goose](https://github.com/block/goose) (Block's open-source AI agent CLI) as a Docker container, pre-wired to the shared `enterprisetools` infrastructure stack and a local Semgrep scanner via four MCP (Model Context Protocol) extensions:

- **SonarQube MCP** — query static analysis results, issues, and code quality metrics
- **Grafana MCP** — read application logs from Loki, explore dashboards, and diagnose issues
- **Semgrep MCP** — scan source code for security vulnerabilities without installing Semgrep on the host
- **chatrecall MCP** — save and search previous Goose session knowledge for continuity across sessions

> **Dependency (local mode):** The `enterprisetools` stack must be running before you start Goose.
> See [`../enterprisetools/README.md`](../enterprisetools/README.md) for setup instructions.

## Local Architecture

```
  cofy/                                        enterprisetools/
  ───────────────────────────────────────      ──────────────────────────────────────
  ┌───────────────────────────────────┐        ┌────────────┐   ┌──────────────────┐
  │           Goose CLI               │        │ SonarQube  │   │     Grafana      │
  │    (ghcr.io/block/goose)          │        │   :9000    │   │     :3000        │
  │                                   │        └────────────┘   └──────────────────┘
  │  MCP extensions:                  │              │                  │
  │  • sonarqube     (stdio)  ────────┼──────────────┘           ┌──────┴─────┐
  │  • grafana       (SSE)    ────────┼─────────────────────────►│ grafana-mcp│
  │  • semgrep       (http)   ─┐      │                          │   :8000    │
  │  • chatrecall    (http)   ─┼─┐    │                          └──────┬─────┘
  └────────────────────────────┼─┼────┘             Loki ◄─ Promtail ◄──┘
                               │ │
                   ┌───────────┘ └────────────────────┐
                   ▼                                  ▼
   ┌─────────────────────────┐        ┌──────────────────────────┐
   │      semgrep-mcp        │        │       chatrecall-mcp     │
   │         :8001           │        │           :8000          │
   │  ./workspace → /src:ro  │        │  SQLite / pgvector store │
   └─────────────────────────┘        └──────────────────────────┘
```

Both stacks communicate over the shared Docker bridge network `enterprisetools`.

## AWS Architecture

```
  Developer laptop
  ┌─────────────────┐
  │ aws-start-      │   ecs run-task        AWS ECS Fargate
  │ session.sh      │──────────────────────────────────────────────────────┐
  └────────┬────────┘                                                      │
           │ ECS Exec (SSM)          VPC  10.10.0.0/16                     │
           │                ┌────────────────────────────────────────────┐ │
           │                │  Private Subnets                           │ │
           └───────────────►│  ┌─────────────────────────────────────┐   │ │
                            │  │  Goose Agent  (on-demand task)      │   │ │
                            │  │  skein-dev-goose-agent              │   │ │
                            │  │                                     │   │ │
                            │  │  env vars injected at startup:      │   │ │
                            │  │  • ANTHROPIC_API_KEY                │   │ │
                            │  │  • SONARQUBE_TOKEN                  │◄──┼─┼── ECR
                            │  │  • GRAFANA_SERVICE_ACCOUNT_TOKEN    │   │ │  skein-dev/
                            │  │                                     │   │ │  goose-agent
                            │  │  MCP extensions:                    │   │ │
                            │  │  • developer  (bundled)             │   │ │
                            │  │  • tom        (bundled)             │   │ │
                            │  │  • chatrecall ──────────────────────┼───┼─┼──┐
                            │  └─────────────────────────────────────┘   │ │  │
                            │                                            │ │  │ streamable_http
                            │  ┌─────────────────────────────────────┐   │ │  │ chatrecall-mcp.
                            │  │  chatrecall-mcp  (always-on service)│◄──┼─┼──┘ skein-dev.local
                            │  │  skein-dev-chatrecall-mcp           │   │ │    :8000/mcp
                            │  │                                     │   │ │
                            │  │  • FastMCP  /mcp                    │◄──┼─┼── ECR
                            │  │  • GET /health  (ECS health check)  │   │ │  skein-dev/
                            │                                            │ │  chatrecall-mcp
                            │  │  • embeds via Bedrock Titan v2 ─────┼───┼─┼──► Bedrock
                            │  │  • stores/searches pgvector    ─────┼───┼─┼──► Aurora
                            │  └─────────────────────────────────────┘   │ │  chatrecall-
                            │                                            │ │  mcp
                            │  DB Subnets                                │ │
                            │  ┌──────────────────────────────────────┐  │ │
                            │  │  Aurora Serverless v2  (0.5–8 ACU)   │  │ │
                            │  │  skein-dev-aurora                    │  │ │
                            │  │  postgres + pgvector  vector(1024)   │  │ │
                            │  └──────────────────────────────────────┘  │ │
                            └────────────────────────────────────────────┘ │
                                         │ outbound via NAT GW             │
                                         ▼                                 │
                              ┌──────────────────────┐                     │
                              │  Anthropic API       │◄────────────────────┘
                              │  (ANTHROPIC_API_KEY) │  GOOSE_PROVIDER=anthropic
                              └──────────────────────┘

AWS Services (outside VPC):
  Secrets Manager  goose/credentials         → ANTHROPIC_API_KEY, SONARQUBE_TOKEN,
                                               GRAFANA_SERVICE_ACCOUNT_TOKEN
                   skein-dev/aurora/credentials → DB_HOST, DB_PORT, DB_USER, DB_PASSWORD
  ECR              skein-dev/goose-agent      → Goose image (baked config + entrypoint)
                   skein-dev/chatrecall-mcp   → chatrecall image
  CloudWatch Logs  /ecs/skein-dev/goose-agent
                   /ecs/skein-dev/chatrecall-mcp
  Route 53 (pvt)   chatrecall-mcp.skein-dev.local
```

**Key differences from local:**

| | Local | AWS |
|---|---|---|
| Goose starts | `docker compose run --rm goose` | `./aws-start-session.sh` → `ecs run-task` |
| TTY session | Docker attach | ECS Exec over SSM |
| API keys | `.env` file | Secrets Manager, injected at task start |
| chatrecall | SQLite in `goose-data/` volume | Aurora pgvector, shared across all agents |
| Extensions selectable | `-e GOOSE_EXTENSIONS=...` | `--extensions ...` flag on `aws-start-session.sh` |
| SonarQube / Grafana | Docker network hostnames | Not wired in AWS (on-demand task has no persistent network peers) |

## Services

| Container | Image | Port | Purpose |
|---|---|---|---|
| `cofy-semgrep-mcp` | `ghcr.io/semgrep/mcp:latest` | `8001` | Semgrep MCP server — scans `/src` for vulnerabilities |
| `cofy-chatrecall-mcp` | local build | `8000` | chatrecall MCP server — session knowledge store |
| `cofy-goose` | `ghcr.io/block/goose:latest` | TTY | Interactive AI agent CLI |

## Prerequisites

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) **or** [Podman Desktop](https://podman-desktop.io/) — see [Container Engine setup](../utils/README.md#container-engine--docker-or-podman)
- `enterprisetools` stack running (provides the `enterprisetools` Docker network and services)
- An [Anthropic API key](https://console.anthropic.com/)
- A SonarQube user token (generated after the `enterprisetools` stack first boots)
- A Grafana service account token (optional but recommended)
- A [Semgrep](https://semgrep.dev/) account and CLI token (free tier available)
- A GitHub Personal Access Token (for `gh` CLI — see [Git & GitHub Setup](#git--github-setup))

## Project Layout

```
cofy/
├── docker-compose.yml          # semgrep-mcp, chatrecall-mcp, and Goose services
├── .env                        # API keys and tokens (not committed)
├── workspace/                  # Mount your project source code here
│   ├── goose.md                # Session-start behaviour instructions for Goose
│   └── context.md              # Platform knowledge injected every turn (via TOM)
├── goose-data/                 # chatrecall persistence volume (gitignored)
├── goose/
│   └── config.yaml             # MCP extension definitions
└── terraform/                  # AWS infrastructure
    └── README.md               # Architecture diagram and deployment guide
```

## Setup

### 1. Start the enterprisetools stack

```bash
git clone # the enterprisetools repo
docker compose up -d
```

Wait for SonarQube to be operational (~2 min), then follow the steps in its README to generate a SonarQube token.

### 2. Configure environment variables

Edit `.env` and fill in your values:

```env
# LLM provider
GOOSE_PROVIDER=anthropic
GOOSE_MODEL=claude-sonnet-4-6
ANTHROPIC_API_KEY=sk-ant-...                          # required

# SonarQube — from enterprisetools first-time setup
SONARQUBE_TOKEN=squ_...

# Grafana MCP — URL of the Grafana instance
GRAFANA_URL=http://grafana:3000

# Grafana service account token (recommended over basic auth)
GRAFANA_SERVICE_ACCOUNT_TOKEN=glsa_...

# Semgrep — token from https://semgrep.dev → Settings → Tokens
SEMGREP_APP_TOKEN=...

# TOM extension — injects context.md into every Goose turn
GOOSE_MOIM_MESSAGE_FILE=/workspace/context.md

# GitHub — SSH key for git push/pull, PAT for gh pr create
GITHUB_TOKEN=ghp_...                                  # required for gh CLI
SSH_AUTH_SOCK=/var/run/com.apple.launchd.xxx/Listeners # auto-set by local-startup.sh on macOS
```

Supported LLM providers:

| Provider  | `GOOSE_PROVIDER` | Key variable.       |
|-----------|------------------|---------------------|
| Anthropic | `anthropic`      | `ANTHROPIC_API_KEY` |
| OpenAI    | `openai`         | `OPENAI_API_KEY`    |
| Google    | `google`         | `GOOGLE_API_KEY`    |

### 3. Start supporting services

```bash
docker compose up -d semgrep-mcp chatrecall-mcp
```

### 4. Start Goose

```bash
docker compose run --rm goose
```

Verify all MCP extensions loaded:

```
goose> /tools
```

You should see tools from `sonarqube`, `grafana`, `semgrep`, and `chatrecall` listed.

## Goose Session Control

### `workspace/goose.md`

Loaded once at session start. Sets Goose's behaviour rules:

- **Wait** for explicit instructions before acting
- **`local` prefix** — disables all public internet access; allows localhost, loopback, Docker network hostnames, and RFC-1918 private ranges
- **`local extensions`** — prints the non-bundled extensions table (Extension, Type, Enabled, Connection) from `~/.config/goose/config.yaml`
- **`status` keyword** — report-only mode; no changes, restarts, or modifications

### `workspace/context.md`

Injected into every Goose turn via the TOM extension (`GOOSE_MOIM_MESSAGE_FILE`). Contains ambient platform knowledge: service hostnames, ports, MCP extension summary, workspace layout, and Loki log labels. Edit this file to keep Goose's working knowledge current without repeating yourself every session.

| File | Purpose | When loaded |
|---|---|---|
| `workspace/goose.md` | Behaviour rules | Session start |
| `workspace/context.md` | Platform knowledge | Every turn (TOM) |

## MCP Extensions

| Extension | How it runs | Transport | Real-world alternative |
|-----------|-------------|-----------|------------------------|
| SonarQube | Transient subprocess (`docker run mcp/sonarqube`) | `stdio` | `streamable_http` or `sse` if running as a persistent server |
| Grafana MCP | Persistent container (`grafana-mcp:8000`) | `sse` | Always `sse` — this server is SSE-only |
| Semgrep MCP | Persistent container (`semgrep-mcp:8000`) | `streamable_http` | Same — already using the modern transport |
| chatrecall MCP | Persistent container (`chatrecall-mcp:8000`) | `streamable_http` | AWS: ECS Service behind Service Discovery DNS |

**On `stdio` vs network transports:** The SonarQube extension uses `stdio` because Goose spawns the MCP server as a child process and communicates over stdin/stdout — no network port needed. In a production deployment where SonarQube MCP runs as a long-lived service, you would change `type: stdio` to `type: streamable_http` and replace `cmd`/`args` with a `url`.

### SonarQube (`mcp/sonarqube`)

**Transport:** stdio — Goose spawns a transient `mcp/sonarqube` container via the mounted Docker socket. The container connects to SonarQube via `host.docker.internal:9000`.

**Sample prompts:**
- _"Analyse the project in /workspace/my-project and summarise the findings."_
- _"List all critical and blocker issues in the `com.example:api` SonarQube project."_
- _"Are there any security hotspots I should address before the next release?"_

### Grafana (`grafana/mcp-grafana`)

**Transport:** SSE — connects to `grafana-mcp:8000/sse` on the shared `enterprisetools` network.

**Environment variables:**

| Variable | Required | Description |
|---|---|---|
| `GRAFANA_URL` | Yes | Grafana URL. Defaults to `http://grafana:3000`. |
| `GRAFANA_SERVICE_ACCOUNT_TOKEN` | Recommended | Service account token. Takes priority over basic auth. |

#### Grafana MCP Setup

1. Open [http://localhost:3000](http://localhost:3000) and log in
2. Go to **Administration → Service Accounts → Add service account**
3. Name it `goose-mcp`, set role to **Viewer**, click **Create**
4. Click **Add service account token**, copy the value
5. Set `GRAFANA_SERVICE_ACCOUNT_TOKEN` in `.env` and restart: `docker compose restart grafana-mcp`

#### Log Reading Activities

| Activity | Example prompt |
|---|---|
| Tail recent logs | _"Show me the last 50 log lines from the payments service."_ |
| Filter by level | _"Show all ERROR and FATAL logs in the last hour across all services."_ |
| Search for a string | _"Find any logs containing 'connection refused' since midnight."_ |
| Query with LogQL | _"Run this LogQL query: `{service=\"api\"} \| json \| level=\"error\"`"_ |
| Debug a deployment | _"What changed in the logs for the auth service after 14:30 today?"_ |

### Semgrep (`ghcr.io/semgrep/mcp`)

**Transport:** streamable_http — connects to `semgrep-mcp:8000/mcp`. Source code in `./workspace` is mounted read-only at `/src` inside the container.

**Security hardening:**

| Flag | Effect |
|---|---|
| `read_only: true` | Container root filesystem is immutable |
| `tmpfs /tmp` | Semgrep scratch space never touches host disk |
| `no-new-privileges` | No Linux capability escalation |
| `./workspace:/src:ro` | Source code mounted read-only |

**Environment variables:**

| Variable | Required | Description |
|---|---|---|
| `SEMGREP_APP_TOKEN` | Yes | CLI token from semgrep.dev → Settings → Tokens |

#### Vulnerability Scanning Activities

| Activity | Example prompt |
|---|---|
| Full scan | _"Run a Semgrep security scan on everything in /workspace."_ |
| Target a language | _"Scan the Java code in /src for SQL injection."_ |
| Check secrets | _"Does the codebase contain any hardcoded API keys?"_ |
| Explain a finding | _"Explain the CWE-89 finding in PaymentService.java line 42."_ |

### chatrecall MCP

**Transport:** streamable_http — connects to `chatrecall-mcp:8000/mcp`. Stores session summaries as vector embeddings (via Bedrock Titan Embed Text v2) and enables fuzzy search across past sessions.

**Local storage:** SQLite database at `./goose-data/` (mounted as a volume).

**AWS storage:** Aurora Serverless v2 with pgvector (see [`terraform/README.md`](./terraform/README.md)).

## AWS Mode

When running on AWS (`GOOSE_ENV=aws`), API keys and tokens are **not** stored in `.env`. Instead, they are injected into the ECS task container at startup from AWS Secrets Manager:

| Secret | Key in `goose/credentials` |
|---|---|
| Anthropic API key | `anthropic_api_key` |
| SonarQube token | `sonarqube_token` |
| Grafana service account token | `grafana_service_account_token` |
| Aurora DB credentials | separate secret, managed by the `aurora` Terraform module |

chatrecall runs as a persistent ECS Service behind Service Discovery DNS (`chatrecall-mcp.goose-dev.local:8000`), shared across all Goose agent tasks.

See [`terraform/README.md`](./terraform/README.md) for deployment instructions.

## Day-to-Day Commands

| Task                      | Command                                           |
|---------------------------|---------------------------------------------------|
| Start supporting services | `docker compose up -d semgrep-mcp chatrecall-mcp` |
| Start Goose               | `docker compose run --rm goose`                   |
| Pull latest images        | `docker compose pull`                             |
| Stop everything           | `docker compose down`                             |
| View chatrecall logs      | `docker compose logs -f chatrecall-mcp`           |
| View semgrep logs         | `docker compose logs -f semgrep-mcp`              |

## Git & GitHub Setup

The Goose container is pre-configured for git push/pull over SSH and pull request creation via the `gh` CLI.

### SSH (git push/pull)

Git operations use SSH tunnelled through the squid proxy via `ssh.github.com:443` — no port 22 required.

The container reads your SSH key from the host SSH agent via a mounted socket. The host agent must be running with at least one key loaded:

```bash
# Check keys are loaded
ssh-add -l

# Load your key if not listed
ssh-add ~/.ssh/id_ed25519
```

`local-startup.sh` handles this automatically on macOS — it resolves the current launchd socket path (which changes on reboot) and writes it to `cofy/.env` each time.

**Windows prerequisite:** Enable and start the OpenSSH Authentication Agent service (run once as admin):

```powershell
Set-Service -Name ssh-agent -StartupType Automatic
Start-Service ssh-agent
ssh-add ~\.ssh\id_ed25519
```

### GitHub CLI (`gh pr create`)

`gh` uses the GitHub REST API, not SSH — a Personal Access Token is required.

Use a **fine-grained token** to limit access to a single org or set of repos (recommended over classic):

1. Go to **github.com → Settings → Developer settings → Personal access tokens → Fine-grained tokens**
2. Click **Generate new token**
3. Set **Resource owner** to your org (e.g. `factoai`)
4. Set **Repository access** → **All repositories** (or pick specific ones)
5. Under **Repository permissions** set:
   - **Contents** → Read and write
   - **Pull requests** → Read and write
   - **Metadata** → Read (auto-selected)
6. Add it to `cofy/.env`:

```env
GITHUB_TOKEN=ghp_your_token_here
```

No `gh auth login` is needed inside the container — `gh` reads `GITHUB_TOKEN` automatically.

> **Org approval:** if fine-grained PATs are restricted by your org, the owner must enable them under **org Settings → Third-party access → Fine-grained personal access tokens**.

## Troubleshooting

### "network enterprisetools not found"

Start the `enterprisetools` stack first:

```bash
cd enterprisetools && docker compose up -d
```

### SonarQube MCP fails to spawn

Confirm the Docker socket is accessible from within the Goose container:

```bash
docker compose run --rm goose docker ps
```

If the command fails, verify that `/var/run/docker.sock` is mounted in `docker-compose.yml`.

### Grafana MCP returns no results

The `grafana-mcp` service may need a moment after Grafana finishes booting:

```bash
cd enterprisetools && docker compose restart grafana-mcp
```

### Semgrep MCP returns no findings or authentication errors

```bash
docker compose logs semgrep-mcp
```

Common causes:
- **Invalid token** — regenerate `SEMGREP_APP_TOKEN` at semgrep.dev and restart
- **Empty workspace** — ensure your project source is inside `./workspace/` before starting the container
- **Rule policy not set** — verify your org has an active rule policy at semgrep.dev

### Switching LLM providers

Update `GOOSE_PROVIDER` and the corresponding API key in `.env`, then restart Goose.
